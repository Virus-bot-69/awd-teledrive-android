package com.awd.teledrive.ui.screens.admin

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import com.awd.teledrive.domain.model.DriveProvider

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    onBack: () -> Unit,
    viewModel: AdminViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    var unlocked by remember { mutableStateOf(false) }
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf<String?>(null) }
    var showForgotDialog by remember { mutableStateOf(false) }
    var showChangePinDialog by remember { mutableStateOf(false) }
    var showRecoveryCodeDialog by remember { mutableStateOf(false) }

    var recoveryCode by remember { mutableStateOf("") }
    var recoveryNewPin by remember { mutableStateOf("") }
    var recoveryConfirmPin by remember { mutableStateOf("") }
    var recoveryError by remember { mutableStateOf<String?>(null) }

    var currentPin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var changeConfirmPin by remember { mutableStateOf("") }
    var changePinError by remember { mutableStateOf<String?>(null) }

    val hasAdminPin by viewModel.hasAdminPin.collectAsState()
    val pendingRecoveryCode by viewModel.pendingRecoveryCode.collectAsState()
    val disabled by viewModel.disabledProviders.collectAsState()
    val notice by viewModel.notice.collectAsState()
    val noticeEnabled by viewModel.noticeEnabled.collectAsState()
    val audit by viewModel.audit.collectAsState()

    var noticeDraft by remember(notice) { mutableStateOf(notice) }

    LaunchedEffect(pendingRecoveryCode) {
        if (!pendingRecoveryCode.isNullOrBlank()) showRecoveryCodeDialog = true
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Admin panel") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        if (!unlocked) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(28.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    Icons.Default.AdminPanelSettings,
                    contentDescription = null,
                    modifier = Modifier.size(56.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(16.dp))
                Text(
                    if (hasAdminPin) "Owner / admin access" else "Set up owner PIN",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    if (hasAdminPin) {
                        "Enter this device's admin PIN. Forgot it? Use the one-time recovery code you saved."
                    } else {
                        "Create a 6–8 digit PIN for this device. You will receive a one-time recovery code; save it somewhere safe."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(20.dp))
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it.filter(Char::isDigit).take(8); pinError = null },
                    label = { Text(if (hasAdminPin) "Admin PIN" else "New PIN (6–8 digits)") },
                    visualTransformation = PasswordVisualTransformation(),
                    isError = pinError != null,
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Next),
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth()
                )
                if (!hasAdminPin) {
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = confirmPin,
                        onValueChange = { confirmPin = it.filter(Char::isDigit).take(8); pinError = null },
                        label = { Text("Confirm new PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        isError = pinError != null,
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Done),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (pinError != null) {
                    Text(
                        pinError ?: "",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = {
                        if (hasAdminPin) {
                            if (viewModel.verifyAdminPin(pin)) {
                                viewModel.logAdminLogin()
                                unlocked = true
                                pin = ""
                            } else {
                                pinError = "Wrong PIN."
                            }
                        } else {
                            when {
                                pin.length !in 6..8 -> pinError = "Use a PIN with 6 to 8 digits."
                                pin != confirmPin -> pinError = "The PINs do not match."
                                !viewModel.createAdminPin(pin) -> pinError = "Could not save the PIN. Try again."
                                else -> {
                                    viewModel.logAdminLogin()
                                    unlocked = true
                                    pin = ""
                                    confirmPin = ""
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (hasAdminPin) "Unlock" else "Create PIN") }
                if (hasAdminPin) {
                    TextButton(onClick = {
                        recoveryCode = ""
                        recoveryNewPin = ""
                        recoveryConfirmPin = ""
                        recoveryError = null
                        showForgotDialog = true
                    }) {
                        Text("Forgot PIN? Use recovery code")
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    "This panel manages local settings on this device only; it does not give access to other users' files or accounts.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                SectionTitle("Owner PIN")
                Text(
                    "This PIN protects this device's local admin panel. It is not your Telegram password and does not control other devices.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { showChangePinDialog = true }) { Text("Change PIN") }
                    TextButton(onClick = { unlocked = false }) { Text("Lock panel") }
                }
                HorizontalDivider()

                Spacer(Modifier.height(16.dp))
                SectionTitle("Providers on this device")
                Text(
                    "Turning a provider off only hides it in Multi Drive on this device. No data is touched.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 10.dp)
                )
                DriveProvider.entries.forEach { provider ->
                    val enabled = provider.key !in disabled
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(provider.displayName, modifier = Modifier.weight(1f))
                        Switch(
                            checked = enabled,
                            onCheckedChange = { viewModel.setProviderEnabled(provider.key, it) }
                        )
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                }

                Spacer(Modifier.height(22.dp))
                SectionTitle("Broadcast notice")
                OutlinedTextField(
                    value = noticeDraft,
                    onValueChange = { noticeDraft = it },
                    label = { Text("Message shown on the Multi Drive tab") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Switch(
                        checked = noticeEnabled,
                        onCheckedChange = { viewModel.setNotice(noticeDraft, it) }
                    )
                    Spacer(Modifier.width(10.dp))
                    Text("Show notice", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { viewModel.setNotice(noticeDraft, true) }) { Text("Save") }
                }

                Spacer(Modifier.height(22.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SectionTitle("Audit log", modifier = Modifier.weight(1f))
                    TextButton(onClick = viewModel::clearAudit) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Clear")
                    }
                }
                Text(
                    "Every admin action and sign-in is recorded locally and visible to the user.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                if (audit.isEmpty()) {
                    Text("No entries yet.", style = MaterialTheme.typography.bodySmall)
                } else {
                    audit.take(60).forEach { entry ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                            Column(Modifier.weight(1f)) {
                                Text(entry.action, style = MaterialTheme.typography.bodySmall)
                                Text(
                                    viewModel.format(entry),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f))
                    }
                }
                Spacer(Modifier.height(30.dp))
            }
        }
    }

    if (showRecoveryCodeDialog && !pendingRecoveryCode.isNullOrBlank()) {
        AlertDialog(
            onDismissRequest = { },
            title = { Text("Save your one-time recovery code") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("This code is shown only until you confirm you saved it. Keep it private; anyone with it can reset this device's admin PIN.")
                    SelectionContainer {
                        Text(
                            pendingRecoveryCode ?: "",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.acknowledgePendingRecoveryCode()
                    showRecoveryCodeDialog = false
                }) { Text("I saved it") }
            }
        )
    }

    if (showForgotDialog) {
        AlertDialog(
            onDismissRequest = { showForgotDialog = false },
            title = { Text("Reset admin PIN") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Enter your one-time recovery code, then create a new 6–8 digit PIN.")
                    OutlinedTextField(
                        value = recoveryCode,
                        onValueChange = { recoveryCode = it; recoveryError = null },
                        label = { Text("Recovery code") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = recoveryNewPin,
                        onValueChange = { recoveryNewPin = it.filter(Char::isDigit).take(8); recoveryError = null },
                        label = { Text("New PIN (6–8 digits)") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Next),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = recoveryConfirmPin,
                        onValueChange = { recoveryConfirmPin = it.filter(Char::isDigit).take(8); recoveryError = null },
                        label = { Text("Confirm new PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Done),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    recoveryError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall) }
                }
            },
            confirmButton = {
                Button(onClick = {
                    when {
                        recoveryNewPin.length !in 6..8 -> recoveryError = "Use a PIN with 6 to 8 digits."
                        recoveryNewPin != recoveryConfirmPin -> recoveryError = "The PINs do not match."
                        !viewModel.resetAdminPinWithRecoveryCode(recoveryCode, recoveryNewPin) ->
                            recoveryError = "Recovery code is incorrect or has already been used."
                        else -> {
                            showForgotDialog = false
                            unlocked = true
                            viewModel.logAdminLogin()
                        }
                    }
                }) { Text("Reset PIN") }
            },
            dismissButton = { TextButton(onClick = { showForgotDialog = false }) { Text("Cancel") } }
        )
    }

    if (showChangePinDialog) {
        AlertDialog(
            onDismissRequest = { showChangePinDialog = false },
            title = { Text("Change admin PIN") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = currentPin,
                        onValueChange = { currentPin = it.filter(Char::isDigit).take(8); changePinError = null },
                        label = { Text("Current PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Next),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newPin,
                        onValueChange = { newPin = it.filter(Char::isDigit).take(8); changePinError = null },
                        label = { Text("New PIN (6–8 digits)") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Next),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = changeConfirmPin,
                        onValueChange = { changeConfirmPin = it.filter(Char::isDigit).take(8); changePinError = null },
                        label = { Text("Confirm new PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Done),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    changePinError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall) }
                }
            },
            confirmButton = {
                Button(onClick = {
                    when {
                        newPin.length !in 6..8 -> changePinError = "Use a PIN with 6 to 8 digits."
                        newPin != changeConfirmPin -> changePinError = "The PINs do not match."
                        !viewModel.changeAdminPin(currentPin, newPin) ->
                            changePinError = "Current PIN is wrong, or the new PIN matches the old one."
                        else -> {
                            showChangePinDialog = false
                            currentPin = ""
                            newPin = ""
                            changeConfirmPin = ""
                            Toast.makeText(context, "Admin PIN changed.", Toast.LENGTH_SHORT).show()
                        }
                    }
                }) { Text("Save PIN") }
            },
            dismissButton = { TextButton(onClick = { showChangePinDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = modifier.padding(bottom = 6.dp)
    )
}
