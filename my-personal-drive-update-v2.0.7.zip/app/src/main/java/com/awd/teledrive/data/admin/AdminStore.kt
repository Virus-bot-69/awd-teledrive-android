package com.awd.teledrive.data.admin

import com.awd.teledrive.data.secure.SecureSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

@Serializable
data class AuditEntry(
    val timestamp: Long,
    val actor: String,
    val action: String
)

/**
 * Local admin/owner settings and PIN for this device.
 *
 * This deliberately does not grant access to another user's files or act as a remote admin.
 * It controls only local provider visibility, the local notice, and the visible audit log.
 */
@Singleton
class AdminStore @Inject constructor(
    private val secureSettings: SecureSettings
) {
    companion object {
        private const val KEY_DISABLED = "admin_disabled_providers"
        private const val KEY_NOTICE = "admin_notice"
        private const val KEY_NOTICE_ON = "admin_notice_enabled"
        private const val KEY_AUDIT = "admin_audit_log"
        private const val KEY_ADMIN_PIN = "owner_admin_pin"
        private const val KEY_RECOVERY_SALT = "owner_admin_recovery_salt"
        private const val KEY_RECOVERY_HASH = "owner_admin_recovery_hash"
        private const val KEY_PENDING_RECOVERY_CODE = "owner_admin_pending_recovery_code"
        private const val MAX_AUDIT = 200
        private const val MIN_PIN_LENGTH = 6
        private const val MAX_PIN_LENGTH = 8
        private const val RECOVERY_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    }

    private val json = Json { ignoreUnknownKeys = true }

    private val _disabledProviders = MutableStateFlow(loadDisabled())
    val disabledProviders: StateFlow<Set<String>> = _disabledProviders.asStateFlow()

    private val _notice = MutableStateFlow(secureSettings.getString(KEY_NOTICE, "") ?: "")
    val notice: StateFlow<String> = _notice.asStateFlow()

    private val _noticeEnabled = MutableStateFlow(secureSettings.getBoolean(KEY_NOTICE_ON, false))
    val noticeEnabled: StateFlow<Boolean> = _noticeEnabled.asStateFlow()

    private val _audit = MutableStateFlow(loadAudit())
    val audit: StateFlow<List<AuditEntry>> = _audit.asStateFlow()

    private val _hasAdminPin = MutableStateFlow(!secureSettings.getString(KEY_ADMIN_PIN).isNullOrBlank())
    val hasAdminPin: StateFlow<Boolean> = _hasAdminPin.asStateFlow()

    private val _pendingRecoveryCode = MutableStateFlow(
        secureSettings.getString(KEY_PENDING_RECOVERY_CODE)?.ifBlank { null }
    )
    val pendingRecoveryCode: StateFlow<String?> = _pendingRecoveryCode.asStateFlow()

    private fun loadDisabled(): Set<String> {
        val raw = secureSettings.getString(KEY_DISABLED, "") ?: ""
        return if (raw.isBlank()) emptySet() else raw.split(',').filter { it.isNotBlank() }.toSet()
    }

    private fun loadAudit(): List<AuditEntry> {
        val raw = secureSettings.getString(KEY_AUDIT, "") ?: ""
        return if (raw.isBlank()) emptyList() else runCatching {
            json.decodeFromString<List<AuditEntry>>(raw)
        }.getOrDefault(emptyList())
    }

    fun hasAdminPin(): Boolean = !secureSettings.getString(KEY_ADMIN_PIN).isNullOrBlank()

    /** First-use setup: no compiled-in default PIN or hidden reset credential. */
    fun createAdminPin(pin: String): Boolean {
        if (hasAdminPin() || !isValidPin(pin)) return false
        secureSettings.saveString(KEY_ADMIN_PIN, pin)
        _hasAdminPin.value = true
        rotateRecoveryCode()
        log("owner", "Created local admin PIN and recovery code")
        return true
    }

    fun verifyAdminPin(pin: String): Boolean {
        val stored = secureSettings.getString(KEY_ADMIN_PIN) ?: return false
        return MessageDigest.isEqual(
            stored.toByteArray(Charsets.UTF_8),
            pin.toByteArray(Charsets.UTF_8)
        )
    }

    fun changeAdminPin(currentPin: String, newPin: String): Boolean {
        if (!verifyAdminPin(currentPin) || !isValidPin(newPin) || currentPin == newPin) return false
        secureSettings.saveString(KEY_ADMIN_PIN, newPin)
        log("owner", "Changed local admin PIN")
        return true
    }

    /** Recovery code is one-time. Successful recovery rotates it and shows the new code once. */
    fun resetAdminPinWithRecoveryCode(recoveryCode: String, newPin: String): Boolean {
        if (!isValidPin(newPin) || !verifyRecoveryCode(recoveryCode)) return false
        secureSettings.saveString(KEY_ADMIN_PIN, newPin)
        _hasAdminPin.value = true
        rotateRecoveryCode()
        log("owner", "Reset local admin PIN with recovery code")
        return true
    }

    fun acknowledgePendingRecoveryCode() {
        secureSettings.saveString(KEY_PENDING_RECOVERY_CODE, "")
        _pendingRecoveryCode.value = null
    }

    fun isProviderEnabled(key: String): Boolean = key !in _disabledProviders.value

    fun setProviderEnabled(key: String, enabled: Boolean, actor: String = "admin") {
        val next = if (enabled) _disabledProviders.value - key else _disabledProviders.value + key
        _disabledProviders.value = next
        secureSettings.saveString(KEY_DISABLED, next.joinToString(","))
        log(actor, if (enabled) "Enabled provider: $key" else "Disabled provider: $key")
    }

    fun setNotice(text: String, enabled: Boolean, actor: String = "admin") {
        _notice.value = text
        _noticeEnabled.value = enabled
        secureSettings.saveString(KEY_NOTICE, text)
        secureSettings.saveBoolean(KEY_NOTICE_ON, enabled)
        log(actor, if (enabled) "Updated notice" else "Notice hidden")
    }

    fun log(actor: String, action: String) {
        val entry = AuditEntry(System.currentTimeMillis(), actor, action)
        val next = (listOf(entry) + _audit.value).take(MAX_AUDIT)
        _audit.value = next
        secureSettings.saveString(KEY_AUDIT, json.encodeToString(next))
    }

    fun clearAudit() {
        _audit.value = emptyList()
        secureSettings.saveString(KEY_AUDIT, "")
    }

    fun formatted(entry: AuditEntry): String =
        SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(entry.timestamp))

    private fun isValidPin(pin: String): Boolean =
        pin.length in MIN_PIN_LENGTH..MAX_PIN_LENGTH && pin.all(Char::isDigit)

    private fun rotateRecoveryCode() {
        val random = SecureRandom()
        val rawCode = buildString(16) {
            repeat(16) { append(RECOVERY_ALPHABET[random.nextInt(RECOVERY_ALPHABET.length)]) }
        }
        val salt = ByteArray(16).also { random.nextBytes(it) }
        secureSettings.saveString(KEY_RECOVERY_SALT, salt.toHex())
        secureSettings.saveString(KEY_RECOVERY_HASH, hashRecoveryCode(rawCode, salt))
        val formatted = rawCode.chunked(4).joinToString("-")
        secureSettings.saveString(KEY_PENDING_RECOVERY_CODE, formatted)
        _pendingRecoveryCode.value = formatted
    }

    private fun verifyRecoveryCode(code: String): Boolean {
        val saltHex = secureSettings.getString(KEY_RECOVERY_SALT) ?: return false
        val expectedHash = secureSettings.getString(KEY_RECOVERY_HASH) ?: return false
        return runCatching {
            val salt = saltHex.hexToBytes()
            val computed = hashRecoveryCode(normalizeRecoveryCode(code), salt)
            MessageDigest.isEqual(computed.toByteArray(Charsets.UTF_8), expectedHash.toByteArray(Charsets.UTF_8))
        }.getOrDefault(false)
    }

    private fun normalizeRecoveryCode(code: String): String =
        code.filter(Char::isLetterOrDigit).uppercase(Locale.ROOT)

    private fun hashRecoveryCode(code: String, salt: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(salt)
        digest.update(code.toByteArray(Charsets.UTF_8))
        return digest.digest().toHex()
    }

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }

    private fun String.hexToBytes(): ByteArray {
        require(length % 2 == 0)
        return ByteArray(length / 2) { index ->
            substring(index * 2, index * 2 + 2).toInt(16).toByte()
        }
    }
}
