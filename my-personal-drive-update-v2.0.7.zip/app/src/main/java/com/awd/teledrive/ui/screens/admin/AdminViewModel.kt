package com.awd.teledrive.ui.screens.admin

import androidx.lifecycle.ViewModel
import com.awd.teledrive.data.admin.AdminStore
import com.awd.teledrive.data.admin.AuditEntry
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class AdminViewModel @Inject constructor(
    private val adminStore: AdminStore
) : ViewModel() {

    val disabledProviders = adminStore.disabledProviders
    val notice = adminStore.notice
    val noticeEnabled = adminStore.noticeEnabled
    val audit = adminStore.audit
    val hasAdminPin = adminStore.hasAdminPin
    val pendingRecoveryCode = adminStore.pendingRecoveryCode

    fun logAdminLogin() = adminStore.log("owner", "Admin panel unlocked")

    fun createAdminPin(pin: String): Boolean = adminStore.createAdminPin(pin)

    fun verifyAdminPin(pin: String): Boolean = adminStore.verifyAdminPin(pin)

    fun changeAdminPin(currentPin: String, newPin: String): Boolean =
        adminStore.changeAdminPin(currentPin, newPin)

    fun resetAdminPinWithRecoveryCode(recoveryCode: String, newPin: String): Boolean =
        adminStore.resetAdminPinWithRecoveryCode(recoveryCode, newPin)

    fun acknowledgePendingRecoveryCode() = adminStore.acknowledgePendingRecoveryCode()

    fun setProviderEnabled(key: String, enabled: Boolean) =
        adminStore.setProviderEnabled(key, enabled)

    fun setNotice(text: String, enabled: Boolean) =
        adminStore.setNotice(text, enabled)

    fun clearAudit() = adminStore.clearAudit()

    fun format(entry: AuditEntry): String = adminStore.formatted(entry)
}
