package com.awd.teledrive.ui.screens.settings

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.graphics.toArgb
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import com.awd.teledrive.R
import com.awd.teledrive.core.BiometricHelper
import com.awd.teledrive.data.repository.SettingsRepository
import com.awd.teledrive.data.repository.UpdateState
import com.awd.teledrive.ui.screens.home.HomeViewModel
import com.awd.teledrive.ui.screens.security.ChangeMasterPasswordDialog
import com.awd.teledrive.ui.screens.security.RecoveryCodeDialog
import com.awd.teledrive.ui.screens.security.SecurityViewModel
import com.awd.teledrive.ui.screens.security.SetRecoveryCodeDialog
import com.awd.teledrive.ui.theme.TeledriveTheme
import com.awd.teledrive.ui.theme.ThemeViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class SettingsUiState(
    val isDarkMode: Boolean,
    val themeColor: Color,
    val backgroundColor: Color?,
    val isSecurityEnabled: Boolean,
    val isPasswordSet: Boolean,
    val isBiometricEnabled: Boolean,
    val backgroundImageUri: String?,
    val apiId: String,
    val apiHash: String,
    val totalStorageUsed: Long,
    val internalCacheSize: Long,
    val cacheSizeLimit: Long,
    val cacheAgeLimit: Int,
    val trashRetentionDays: Int,
    val isAutoBackupEnabled: Boolean,
    val lastBackupTime: Long,
    val currentLanguage: String,
    val downloadUri: String?,
    val versionName: String,
    val versionCode: Long,
    val updateState: UpdateState
)

@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onNavigateToBackupFolders: () -> Unit,
    onNavigateToTrash: () -> Unit,
    onNavigateToLogs: () -> Unit,
    onNavigateToCacheDetails: () -> Unit,
    onNavigateToCloudAnalysis: () -> Unit,
    onNavigateToAbout: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel(),
    themeViewModel: ThemeViewModel = hiltViewModel(),
    securityViewModel: SecurityViewModel = hiltViewModel(),
    homeViewModel: HomeViewModel = hiltViewModel(),
    backupViewModel: BackupViewModel = hiltViewModel()
) {
    val isDarkMode by themeViewModel.isDarkMode.collectAsState()
    val themeColor by themeViewModel.themeColor.collectAsState()
    val backgroundColor by themeViewModel.backgroundColor.collectAsState()
    val isSecurityEnabled by securityViewModel.isSecurityEnabled.collectAsState()
    val isPasswordSet by securityViewModel.isPasswordSet.collectAsState()
    val isBiometricEnabled by securityViewModel.isBiometricEnabled.collectAsState()
    val backgroundImageUri by themeViewModel.backgroundImageUri.collectAsState()
    val apiCredentials by viewModel.apiCredentials.collectAsState()
    val totalStorageUsed by homeViewModel.totalStorageUsed.collectAsState()
    val internalCacheSize by viewModel.internalCacheSize.collectAsState()
    val cacheSizeLimit by viewModel.cacheSizeLimit.collectAsState()
    val cacheAgeLimit by viewModel.cacheAgeLimit.collectAsState()
    val trashRetentionDays by viewModel.trashRetentionDays.collectAsState()
    val isAutoBackupEnabled by backupViewModel.isAutoBackupEnabled.collectAsState()
    val isBackupWifiOnly by backupViewModel.isBackupWifiOnly.collectAsState()
    val lastBackupTime by backupViewModel.lastBackupTime.collectAsState()
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val downloadUri by viewModel.downloadUri.collectAsState()
    val updateState by viewModel.updateState.collectAsState()
    val isThumbnailAutoDownloadEnabled by viewModel.isThumbnailAutoDownloadEnabled.collectAsState()
    val showCacheWarning by viewModel.showCacheWarning.collectAsState()
    val cloudBackups by viewModel.cloudBackups.collectAsState()

    val context = LocalContext.current

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        uri?.let {
            val json = viewModel.exportMetadata()
            context.contentResolver.openOutputStream(it)?.use { out ->
                out.write(json.toByteArray())
            }
            Toast.makeText(context, context.getString(R.string.export_success, it.path ?: ""), Toast.LENGTH_LONG).show()
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            context.contentResolver.openInputStream(it)?.use { input ->
                val json = input.bufferedReader().readText()
                if (viewModel.importMetadata(json)) {
                    Toast.makeText(context, context.getString(R.string.import_success), Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, context.getString(R.string.import_fail_format), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        backupViewModel.feedback.collect { feedback ->
            val msg = when (feedback) {
                BackupFeedback.NoFolders -> context.getString(R.string.no_backup_folders)
                BackupFeedback.StorageAccessRequired -> context.getString(R.string.backup_storage_access_required)
                BackupFeedback.Starting -> context.getString(R.string.backup_starting)
            }
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }

    val uiState = SettingsUiState(
        isDarkMode = isDarkMode ?: isSystemInDarkTheme(),
        themeColor = themeColor,
        backgroundColor = backgroundColor,
        isSecurityEnabled = isSecurityEnabled,
        isPasswordSet = isPasswordSet,
        isBiometricEnabled = isBiometricEnabled,
        backgroundImageUri = backgroundImageUri,
        apiId = apiCredentials.first.toString(),
        apiHash = apiCredentials.second,
        totalStorageUsed = totalStorageUsed,
        internalCacheSize = internalCacheSize,
        cacheSizeLimit = cacheSizeLimit,
        cacheAgeLimit = cacheAgeLimit,
        trashRetentionDays = trashRetentionDays,
        isAutoBackupEnabled = isAutoBackupEnabled,
        lastBackupTime = lastBackupTime,
        currentLanguage = currentLanguage,
        downloadUri = downloadUri,
        versionName = viewModel.versionName,
        versionCode = viewModel.versionCode,
        updateState = updateState
    )

    SettingsContent(
        uiState = uiState,
        isThumbnailAutoDownloadEnabled = isThumbnailAutoDownloadEnabled,
        isBackupWifiOnly = isBackupWifiOnly,
        onBack = onBack,
        onLogout = {
            viewModel.logout()
            // Memberikan sedikit waktu bagi TDLib untuk mengirim request logout sebelum restart
            val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)
            intent?.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP or android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            (context as? android.app.Activity)?.finish()
        },
        onNavigateToBackupFolders = onNavigateToBackupFolders,
        onNavigateToTrash = onNavigateToTrash,
        onNavigateToCacheDetails = onNavigateToCacheDetails,
        onNavigateToCloudAnalysis = onNavigateToCloudAnalysis,
        onNavigateToAbout = onNavigateToAbout,
        onSetDarkMode = { themeViewModel.setDarkMode(it) },
        onSetThemeColor = { themeViewModel.setThemeColor(it) },
        onSetBackgroundColor = { themeViewModel.setBackgroundColor(it) },
        onSetSecurityEnabled = { securityViewModel.setSecurityEnabled(it) },
        onSetMasterPassword = { securityViewModel.setPassword(it) },
        onTakePendingRecoveryCode = securityViewModel::takePendingRecoveryCode,
        onChangeMasterPassword = securityViewModel::changePassword,
        onCreateRecoveryCode = securityViewModel::createNewRecoveryCode,
        onSetBiometricEnabled = { enabled ->
            if (!enabled) {
                securityViewModel.setBiometricEnabled(false)
            } else if (!BiometricHelper.canAuthenticate(context)) {
                Toast.makeText(context, "Set up a fingerprint or face unlock on this device first.", Toast.LENGTH_LONG).show()
            } else {
                val activity = BiometricHelper.findFragmentActivity(context)
                if (activity == null) {
                    Toast.makeText(context, "Biometric unlock is unavailable in this screen.", Toast.LENGTH_LONG).show()
                } else {
                    BiometricHelper.showPrompt(
                        activity,
                        title = "Enable biometric unlock",
                        onSuccess = {
                            securityViewModel.setBiometricEnabled(true)
                            Toast.makeText(context, "Biometric unlock is on.", Toast.LENGTH_SHORT).show()
                        },
                        onError = { message ->
                            Toast.makeText(context, "Biometric setup cancelled: $message", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }
        },
        onSaveApiCredentials = { id, hash ->
            viewModel.saveApiCredentials(id, hash)
            Toast.makeText(context, "Telegram API saved for the next login.", Toast.LENGTH_LONG).show()
        },
        onSetBackgroundImage = { themeViewModel.setBackgroundImage(it) },
        onSetAutoBackupEnabled = { backupViewModel.setAutoBackupEnabled(it) },
        onSetBackupWifiOnly = { backupViewModel.setBackupWifiOnly(it) },
        onTriggerManualBackup = { backupViewModel.triggerManualBackup() },
        onNavigateToLogs = onNavigateToLogs,
        onClearCache = viewModel::clearCache,
        onSetLanguage = viewModel::setLanguage,
        onSetDownloadUri = viewModel::setDownloadUri,
        onSetCacheSizeLimit = viewModel::setCacheSizeLimit,
        onSetCacheAgeLimit = viewModel::setCacheAgeLimit,
        onSetTrashRetentionDays = viewModel::setTrashRetentionDays,
        onSetThumbnailAutoDownload = viewModel::setThumbnailAutoDownloadEnabled,
        showCacheWarning = showCacheWarning,
        onDismissCacheWarning = viewModel::dismissCacheWarning,
        onExportMetadata = {
            exportLauncher.launch("teledrive_metadata_${System.currentTimeMillis()}.json")
        },
        onImportMetadata = {
            importLauncher.launch("application/json")
        },
        onManualCloudBackup = {
            viewModel.triggerCloudMetadataBackup()
            Toast.makeText(context, context.getString(R.string.backup_sent_saved), Toast.LENGTH_SHORT).show()
        },
        cloudBackups = cloudBackups,
        onLoadCloudBackups = viewModel::loadCloudBackups,
        onRestoreCloudBackup = { msgId ->
            viewModel.restoreCloudBackup(msgId) { success ->
                if (success) {
                    Toast.makeText(context, context.getString(R.string.import_success), Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, context.getString(R.string.restore_fail), Toast.LENGTH_LONG).show()
                }
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun SettingsContent(
    uiState: SettingsUiState,
    isThumbnailAutoDownloadEnabled: Boolean,
    isBackupWifiOnly: Boolean,
    showCacheWarning: Boolean,
    onBack: () -> Unit,
    onLogout: () -> Unit,
    onNavigateToBackupFolders: () -> Unit,
    onNavigateToTrash: () -> Unit,
    onNavigateToCacheDetails: () -> Unit,
    onNavigateToCloudAnalysis: () -> Unit,
    onNavigateToAbout: () -> Unit,
    onSetDarkMode: (Boolean) -> Unit,
    onSetThemeColor: (Color) -> Unit,
    onSetBackgroundColor: (Color?) -> Unit,
    onSetSecurityEnabled: (Boolean) -> Unit,
    onSetMasterPassword: (String) -> Boolean,
    onTakePendingRecoveryCode: () -> String?,
    onChangeMasterPassword: (String, String) -> Boolean,
    onCreateRecoveryCode: (String) -> String?,
    onSetBiometricEnabled: (Boolean) -> Unit,
    onSaveApiCredentials: (Int, String) -> Unit,
    onSetBackgroundImage: (String?) -> Unit,
    onSetAutoBackupEnabled: (Boolean) -> Unit,
    onSetBackupWifiOnly: (Boolean) -> Unit,
    onTriggerManualBackup: () -> Unit,
    onNavigateToLogs: () -> Unit,
    onClearCache: () -> Unit,
    onSetLanguage: (String) -> Unit,
    onSetDownloadUri: (String?) -> Unit,
    onSetCacheSizeLimit: (Long) -> Unit,
    onSetCacheAgeLimit: (Int) -> Unit,
    onSetTrashRetentionDays: (Int) -> Unit,
    onSetThumbnailAutoDownload: (Boolean) -> Unit,
    onDismissCacheWarning: () -> Unit,
    onExportMetadata: () -> Unit,
    onImportMetadata: () -> Unit,
    onManualCloudBackup: () -> Unit,
    cloudBackups: List<com.awd.teledrive.domain.model.CloudBackup>,
    onLoadCloudBackups: () -> Unit,
    onRestoreCloudBackup: (Long) -> Unit
) {
    var showLanguageDialog by remember { mutableStateOf(false) }
    var showMasterPasswordDialog by remember { mutableStateOf(false) }
    var showChangeMasterPasswordDialog by remember { mutableStateOf(false) }
    var showRecoveryCodeSetupDialog by remember { mutableStateOf(false) }
    var recoveryCodeToShow by remember { mutableStateOf<String?>(null) }
    var showApiCredentialsDialog by remember { mutableStateOf(false) }
    var masterPasswordDraft by remember { mutableStateOf("") }
    var confirmMasterPasswordDraft by remember { mutableStateOf("") }
    var masterPasswordError by remember { mutableStateOf<String?>(null) }
    var masterPasswordVisible by remember { mutableStateOf(false) }
    var apiIdDraft by remember { mutableStateOf("") }
    var apiHashDraft by remember { mutableStateOf("") }
    var apiCredentialsError by remember { mutableStateOf<String?>(null) }
    var apiHashVisible by remember { mutableStateOf(false) }
    var customColorHex by remember { mutableStateOf("#24A1DE") }
    var customColorError by remember { mutableStateOf(false) }
    var showLanguageRestartConfirm by remember { mutableStateOf(false) }
    var showCacheSizeDialog by remember { mutableStateOf(false) }
    var showCacheAgeDialog by remember { mutableStateOf(false) }
    var showTrashRetentionDialog by remember { mutableStateOf(false) }
    var showCustomTrashRetentionDialog by remember { mutableStateOf(false) }
    var customTrashRetentionDays by remember { mutableStateOf("") }
    var showImportConfirm by remember { mutableStateOf(false) }
    var showCloudBackupsDialog by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val scrollState = rememberScrollState()
    var showClearCacheConfirm by remember { mutableStateOf(false) }
    var showLogoutConfirm by remember { mutableStateOf(false) }
    var showThemeRestartConfirm by remember { mutableStateOf(false) }
    var showThemeColorDialog by remember { mutableStateOf(false) }
    var showBackgroundColorDialog by remember { mutableStateOf(false) }
    var backgroundColorHex by remember { mutableStateOf(if (uiState.isDarkMode) "#FF1C1B1F" else "#FFFFFBFE") }
    var backgroundColorError by remember { mutableStateOf(false) }

    val folderLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        uri?.let {
            val takeFlags: Int = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            context.contentResolver.takePersistableUriPermission(it, takeFlags)
            onSetDownloadUri(it.toString())
        }
    }

    val backgroundImageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            try {
                context.contentResolver.takePersistableUriPermission(
                    it,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) { }
            onSetBackgroundImage(it.toString())
        }
    }

    if (showLanguageRestartConfirm) {
        AlertDialog(
            onDismissRequest = { showLanguageRestartConfirm = false },
            title = { Text(stringResource(R.string.language_changed_title)) },
            text = { Text(stringResource(R.string.language_changed_message)) },
            confirmButton = {
                TextButton(onClick = {
                    showLanguageRestartConfirm = false
                    val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)
                    intent?.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP or android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    (context as? android.app.Activity)?.finish()
                }) { Text(stringResource(R.string.restart_app)) }
            },
            dismissButton = {
                TextButton(onClick = { showLanguageRestartConfirm = false }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }

    if (showTrashRetentionDialog) {
        AlertDialog(
            onDismissRequest = { showTrashRetentionDialog = false },
            title = { Text("Trash retention") },
            text = {
                Column {
                    Text("Choose how long items stay recoverable. Never is the default and keeps items until you delete them permanently.")
                    listOf(-1 to "Never", 7 to "7 days", 30 to "30 days", 90 to "90 days", 365 to "1 year").forEach { (days, label) ->
                        TextButton(
                            onClick = {
                                onSetTrashRetentionDays(days)
                                showTrashRetentionDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (uiState.trashRetentionDays == days) "✓ $label" else label) }
                    }
                    TextButton(
                        onClick = {
                            customTrashRetentionDays = if (uiState.trashRetentionDays > 0) uiState.trashRetentionDays.toString() else ""
                            showTrashRetentionDialog = false
                            showCustomTrashRetentionDialog = true
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Custom number of days…") }
                }
            },
            confirmButton = { TextButton(onClick = { showTrashRetentionDialog = false }) { Text("Close") } }
        )
    }

    if (showCustomTrashRetentionDialog) {
        AlertDialog(
            onDismissRequest = { showCustomTrashRetentionDialog = false },
            title = { Text("Custom Trash retention") },
            text = {
                Column {
                    Text("Enter a number of days (1–3650).")
                    OutlinedTextField(
                        value = customTrashRetentionDays,
                        onValueChange = { customTrashRetentionDays = it.filter(Char::isDigit) },
                        label = { Text("Days") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val days = customTrashRetentionDays.toIntOrNull()
                    if (days != null && days in 1..3650) {
                        onSetTrashRetentionDays(days)
                        showCustomTrashRetentionDialog = false
                    } else {
                        Toast.makeText(context, "Enter a value from 1 to 3650 days.", Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showCustomTrashRetentionDialog = false }) { Text("Cancel") } }
        )
    }

    if (showMasterPasswordDialog) {
        AlertDialog(
            onDismissRequest = {
                showMasterPasswordDialog = false
                masterPasswordDraft = ""
                confirmMasterPasswordDraft = ""
                masterPasswordError = null
                masterPasswordVisible = false
            },
            title = { Text("Set Master Password") },
            text = {
                Column {
                    Text("Enter a password, repeat the same password below, then tap Save. The app will lock when you leave it. Keep the password somewhere safe.")
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = masterPasswordDraft,
                        onValueChange = { masterPasswordDraft = it; masterPasswordError = null },
                        label = { Text("Password") },
                        visualTransformation = if (masterPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            IconButton(onClick = { masterPasswordVisible = !masterPasswordVisible }) {
                                Icon(
                                    if (masterPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = if (masterPasswordVisible) "Hide password" else "Show password"
                                )
                            }
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = confirmMasterPasswordDraft,
                        onValueChange = { confirmMasterPasswordDraft = it; masterPasswordError = null },
                        label = { Text("Confirm password") },
                        visualTransformation = if (masterPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            IconButton(onClick = { masterPasswordVisible = !masterPasswordVisible }) {
                                Icon(
                                    if (masterPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = if (masterPasswordVisible) "Hide password" else "Show password"
                                )
                            }
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (masterPasswordError != null) {
                        Text(masterPasswordError ?: "", color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    when {
                        masterPasswordDraft.length < 4 -> masterPasswordError = "Use at least 4 characters."
                        masterPasswordDraft != confirmMasterPasswordDraft -> masterPasswordError = "Passwords do not match."
                        !onSetMasterPassword(masterPasswordDraft) -> masterPasswordError = "Could not save the password securely. Try again."
                        else -> {
                            recoveryCodeToShow = onTakePendingRecoveryCode()
                            showMasterPasswordDialog = false
                            masterPasswordDraft = ""
                            confirmMasterPasswordDraft = ""
                            masterPasswordError = null
                            masterPasswordVisible = false
                            Toast.makeText(context, "Master Password is on.", Toast.LENGTH_SHORT).show()
                        }
                    }
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = {
                    showMasterPasswordDialog = false
                    masterPasswordDraft = ""
                    confirmMasterPasswordDraft = ""
                    masterPasswordError = null
                }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }

    if (showChangeMasterPasswordDialog) {
        ChangeMasterPasswordDialog(
            onDismiss = { showChangeMasterPasswordDialog = false },
            onChangePassword = { currentPassword, newPassword ->
                val changed = onChangeMasterPassword(currentPassword, newPassword)
                if (changed) Toast.makeText(context, "Master Password changed.", Toast.LENGTH_SHORT).show()
                changed
            }
        )
    }

    if (showRecoveryCodeSetupDialog) {
        SetRecoveryCodeDialog(
            onDismiss = { showRecoveryCodeSetupDialog = false },
            onCreateRecoveryCode = onCreateRecoveryCode,
            onCodeCreated = { recoveryCodeToShow = it }
        )
    }

    recoveryCodeToShow?.let { code ->
        RecoveryCodeDialog(
            code = code,
            onDismiss = { recoveryCodeToShow = null }
        )
    }

    if (showApiCredentialsDialog) {
        AlertDialog(
            onDismissRequest = { showApiCredentialsDialog = false; apiCredentialsError = null },
            title = { Text("Telegram API credentials") },
            text = {
                Column {
                    Text("Saved credentials are hidden. Enter your own API ID and API Hash to override the built-in values; they are stored only on this device. A new Telegram login may be needed for changes to take effect.")
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = apiIdDraft,
                        onValueChange = { apiIdDraft = it.filter(Char::isDigit); apiCredentialsError = null },
                        label = { Text("API ID") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = apiHashDraft,
                        onValueChange = { apiHashDraft = it.trim(); apiCredentialsError = null },
                        label = { Text("API Hash") },
                        visualTransformation = if (apiHashVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { apiHashVisible = !apiHashVisible }) {
                                Icon(
                                    if (apiHashVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = if (apiHashVisible) "Hide API Hash" else "Show API Hash"
                                )
                            }
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (apiCredentialsError != null) {
                        Text(apiCredentialsError ?: "", color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val parsedId = apiIdDraft.toIntOrNull()
                    if (parsedId == null || parsedId <= 0 || apiHashDraft.trim().length < 10) {
                        apiCredentialsError = "Enter a valid API ID and API Hash."
                    } else {
                        onSaveApiCredentials(parsedId, apiHashDraft.trim())
                        showApiCredentialsDialog = false
                        apiCredentialsError = null
                    }
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showApiCredentialsDialog = false; apiCredentialsError = null }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }

    if (showLogoutConfirm) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirm = false },
            title = { Text(stringResource(R.string.logout_confirm_title)) },
            text = { Text(stringResource(R.string.logout_confirm_message)) },
            confirmButton = {
                TextButton(onClick = {
                    showLogoutConfirm = false
                    onLogout()
                }) { Text(stringResource(R.string.logout), color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirm = false }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }

    if (showClearCacheConfirm) {
        AlertDialog(
            onDismissRequest = { showClearCacheConfirm = false },
            title = { Text(stringResource(R.string.clear_cache_confirm_title)) },
            text = { Text(stringResource(R.string.clear_cache_confirm_message)) },
            confirmButton = {
                TextButton(onClick = {
                    onClearCache()
                    showClearCacheConfirm = false
                    Toast.makeText(context, context.getString(R.string.cache_cleared), Toast.LENGTH_SHORT).show()
                }) { Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showClearCacheConfirm = false }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }

    if (showThemeRestartConfirm) {
        AlertDialog(
            onDismissRequest = { showThemeRestartConfirm = false },
            title = { Text(stringResource(R.string.theme_changed_title)) },
            text = { Text(stringResource(R.string.theme_changed_message)) },
            confirmButton = {
                TextButton(onClick = {
                    showThemeRestartConfirm = false
                    val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)
                    intent?.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP or android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    (context as? android.app.Activity)?.finish()
                }) { Text(stringResource(R.string.restart_app)) }
            },
            dismissButton = {
                TextButton(onClick = { showThemeRestartConfirm = false }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }

    if (showLanguageDialog) {
        AlertDialog(
            onDismissRequest = { showLanguageDialog = false },
            title = { Text(stringResource(R.string.language)) },
            text = {
                Column {
                    ListItem(
                        headlineContent = { Text("English") },
                        modifier = Modifier.clickable {
                            onSetLanguage("en")
                            showLanguageDialog = false
                            showLanguageRestartConfirm = true
                        },
                        trailingContent = {
                            if (uiState.currentLanguage == "en") Icon(Icons.Default.Check, null)
                        }
                    )
                    ListItem(
                        headlineContent = { Text("Bahasa Indonesia") },
                        modifier = Modifier.clickable {
                            onSetLanguage("id")
                            showLanguageDialog = false
                            showLanguageRestartConfirm = true
                        },
                        trailingContent = {
                            if (uiState.currentLanguage == "id" || uiState.currentLanguage == "in") Icon(Icons.Default.Check, null)
                        }
                    )
                }
            },
            confirmButton = {}
        )
    }

    if (showCacheSizeDialog) {
        AlertDialog(
            onDismissRequest = { showCacheSizeDialog = false },
            title = { Text(stringResource(R.string.cache_size_limit)) },
            text = {
                Column {
                    SettingsRepository.CACHE_SIZE_OPTIONS.forEach { option: Long ->
                        ListItem(
                            headlineContent = { Text(if (option == 0L) stringResource(R.string.no_limit) else formatSize(option)) },
                            modifier = Modifier.clickable {
                                onSetCacheSizeLimit(option)
                                showCacheSizeDialog = false
                            },
                            trailingContent = {
                                if (uiState.cacheSizeLimit == option) Icon(Icons.Default.Check, null)
                            }
                        )
                    }
                }
            },
            confirmButton = {}
        )
    }

    if (showCacheAgeDialog) {
        AlertDialog(
            onDismissRequest = { showCacheAgeDialog = false },
            title = { Text(stringResource(R.string.media_age_limit)) },
            text = {
                Column {
                    SettingsRepository.CACHE_AGE_OPTIONS.forEach { option: Int ->
                        ListItem(
                            headlineContent = { Text(formatCacheAge(option, context)) },
                            modifier = Modifier.clickable {
                                onSetCacheAgeLimit(option)
                                showCacheAgeDialog = false
                            },
                            trailingContent = {
                                if (uiState.cacheAgeLimit == option) Icon(Icons.Default.Check, null)
                            }
                        )
                    }
                }
            },
            confirmButton = {}
        )
    }

    if (showBackgroundColorDialog) {
        AlertDialog(
            onDismissRequest = { showBackgroundColorDialog = false; backgroundColorError = false },
            title = { Text("Background color") },
            text = {
                Column {
                    Text("Choose a color for the app background, or enter a hex value.")
                    Spacer(Modifier.height(10.dp))
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth().height(150.dp)
                    ) {
                        val colors = listOf(
                            Color(0xFF121212), Color(0xFF1C1B1F), Color(0xFF263238), Color(0xFF0D1B2A),
                            Color(0xFF37474F), Color(0xFF3E2723), Color(0xFF1B4332), Color(0xFF2D1E40),
                            Color(0xFFF5F5F5), Color(0xFFFFFBFE), Color(0xFFE3F2FD), Color(0xFFFFF3E0)
                        )
                        items(colors) { color ->
                            Surface(
                                onClick = {
                                    onSetBackgroundColor(color)
                                    showBackgroundColorDialog = false
                                },
                                color = color,
                                shape = CircleShape,
                                modifier = Modifier.size(42.dp),
                                border = if (uiState.backgroundColor == color)
                                    BorderStroke(3.dp, MaterialTheme.colorScheme.primary) else BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                                tonalElevation = 2.dp
                            ) { }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = backgroundColorHex,
                        onValueChange = { backgroundColorHex = it.take(9); backgroundColorError = false },
                        label = { Text("Custom color (#RRGGBB or #AARRGGBB)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (backgroundColorError) {
                        Text("Enter a valid hex color, for example #20242A.", color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    try {
                        onSetBackgroundColor(Color(android.graphics.Color.parseColor(backgroundColorHex.trim())))
                        showBackgroundColorDialog = false
                        backgroundColorError = false
                    } catch (_: IllegalArgumentException) {
                        backgroundColorError = true
                    }
                }) { Text("Apply") }
            },
            dismissButton = {
                androidx.compose.foundation.layout.Row {
                    TextButton(onClick = {
                        onSetBackgroundColor(null)
                        showBackgroundColorDialog = false
                        backgroundColorError = false
                    }) { Text("Use default") }
                    TextButton(onClick = { showBackgroundColorDialog = false; backgroundColorError = false }) {
                        Text(stringResource(R.string.cancel))
                    }
                }
            }
        )
    }

    if (showThemeColorDialog) {
        AlertDialog(
            onDismissRequest = { showThemeColorDialog = false; customColorError = false },
            title = { Text(stringResource(R.string.theme_color)) },
            text = {
                Column {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth().height(190.dp)
                    ) {
                        val colors = listOf(
                            Color(0xFF24A1DE), Color(0xFF673AB7), Color(0xFF3F51B5),
                            Color(0xFF2196F3), Color(0xFF00BCD4), Color(0xFF009688),
                            Color(0xFF4CAF50), Color(0xFF8BC34A), Color(0xFFFFC107),
                            Color(0xFFFF9800), Color(0xFFFF5722), Color(0xFFE91E63),
                            Color(0xFF9C27B0), Color(0xFF607D8B)
                        )
                        items(colors) { color ->
                            Surface(
                                onClick = {
                                    onSetThemeColor(color)
                                    showThemeColorDialog = false
                                    showThemeRestartConfirm = true
                                },
                                color = color,
                                shape = CircleShape,
                                modifier = Modifier.size(48.dp),
                                border = if (uiState.themeColor == color)
                                    BorderStroke(3.dp, MaterialTheme.colorScheme.onSurface) else null,
                                tonalElevation = 4.dp
                            ) {
                                if (uiState.themeColor == color) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.White)
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = customColorHex,
                        onValueChange = { customColorHex = it.take(9); customColorError = false },
                        label = { Text("Custom color (#RRGGBB or #AARRGGBB)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (customColorError) {
                        Text("Enter a valid hex color, for example #24A1DE.", color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    try {
                        onSetThemeColor(Color(android.graphics.Color.parseColor(customColorHex.trim())))
                        showThemeColorDialog = false
                        customColorError = false
                        showThemeRestartConfirm = true
                    } catch (_: IllegalArgumentException) {
                        customColorError = true
                    }
                }) { Text("Apply custom color") }
            },
            dismissButton = {
                TextButton(onClick = { showThemeColorDialog = false; customColorError = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(stringResource(R.string.settings)) },
                modifier = Modifier.statusBarsPadding()
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
        ) {
            SettingsCategory(title = stringResource(R.string.display))
            SettingsToggleRow(
                icon = Icons.Default.DarkMode,
                title = stringResource(R.string.theme_dark),
                checked = uiState.isDarkMode,
                onCheckedChange = { 
                    onSetDarkMode(it)
                    showThemeRestartConfirm = true
                }
            )

            SettingsToggleRow(
                icon = Icons.Default.PhotoLibrary,
                title = stringResource(R.string.auto_download_thumbnails),
                subtitle = stringResource(R.string.auto_download_thumbnails_desc),
                checked = isThumbnailAutoDownloadEnabled,
                onCheckedChange = onSetThumbnailAutoDownload
            )
            
            SettingsClickableRow(
                icon = Icons.Default.Check,
                title = stringResource(R.string.theme_color),
                subtitle = stringResource(R.string.choose_color_desc),
                onClick = { showThemeColorDialog = true }
            )

            SettingsClickableRow(
                icon = Icons.Default.Check,
                title = "Background color",
                subtitle = if (uiState.backgroundColor == null) "Choose a custom app background" else "Custom color applied",
                onClick = {
                    backgroundColorHex = uiState.backgroundColor?.let { String.format(Locale.ROOT, "#%08X", it.toArgb()) }
                        ?: if (uiState.isDarkMode) "#FF1C1B1F" else "#FFFFFBFE"
                    backgroundColorError = false
                    showBackgroundColorDialog = true
                }
            )

            SettingsClickableRow(
                icon = Icons.Default.PhotoLibrary,
                title = "Custom background image",
                subtitle = if (uiState.backgroundImageUri.isNullOrBlank()) "Choose an image from this device" else "Image selected · Tap to replace",
                onClick = { backgroundImageLauncher.launch(arrayOf("image/*")) }
            )
            if (!uiState.backgroundImageUri.isNullOrBlank()) {
                TextButton(
                    onClick = { onSetBackgroundImage(null) },
                    modifier = Modifier.padding(horizontal = 16.dp)
                ) { Text("Remove background image") }
            }

            SettingsClickableRow(
                icon = Icons.Default.Language,
                title = stringResource(R.string.language),
                subtitle = if (uiState.currentLanguage == "in" || uiState.currentLanguage == "id") "Bahasa Indonesia" else "English",
                onClick = { showLanguageDialog = true }
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            SettingsCategory(title = stringResource(R.string.security))
            SettingsToggleRow(
                icon = Icons.Default.VpnKey,
                title = stringResource(R.string.master_password),
                subtitle = stringResource(R.string.require_password),
                checked = uiState.isSecurityEnabled,
                onCheckedChange = { enabled ->
                    if (!enabled) {
                        onSetSecurityEnabled(false)
                    } else if (uiState.isPasswordSet) {
                        onSetSecurityEnabled(true)
                    } else {
                        masterPasswordDraft = ""
                        confirmMasterPasswordDraft = ""
                        masterPasswordError = null
                        masterPasswordVisible = false
                        showMasterPasswordDialog = true
                    }
                }
            )
            SettingsToggleRow(
                icon = Icons.Default.Fingerprint,
                title = stringResource(R.string.biometric_unlock),
                checked = uiState.isBiometricEnabled,
                enabled = uiState.isSecurityEnabled && uiState.isPasswordSet,
                onCheckedChange = onSetBiometricEnabled
            )
            if (uiState.isPasswordSet) {
                SettingsClickableRow(
                    icon = Icons.Default.VpnKey,
                    title = "Change Master Password",
                    subtitle = "Verify your current password and set a new one",
                    onClick = { showChangeMasterPasswordDialog = true }
                )
                SettingsClickableRow(
                    icon = Icons.Default.VpnKey,
                    title = "One-time recovery code",
                    subtitle = "Generate or replace the code after verifying your current password",
                    onClick = { showRecoveryCodeSetupDialog = true }
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            SettingsCategory(title = stringResource(R.string.telegram_api))
            SettingsClickableRow(
                icon = Icons.Default.VpnKey,
                title = "Edit Telegram API credentials",
                subtitle = "Credentials are hidden · Tap to enter or replace",
                onClick = {
                    apiIdDraft = ""
                    apiHashDraft = ""
                    apiHashVisible = false
                    apiCredentialsError = null
                    showApiCredentialsDialog = true
                }
            )
            Text(
                "API credentials stay on this device. A new login may be needed for changes to take effect.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            SettingsCategory(title = stringResource(R.string.storage))

            SettingsClickableRow(
                icon = Icons.Default.History,
                title = "Trash",
                subtitle = "Restore items or permanently remove them from Telegram",
                onClick = onNavigateToTrash
            )
            SettingsClickableRow(
                icon = Icons.Default.History,
                title = "Trash retention",
                subtitle = if (uiState.trashRetentionDays < 0) "Never auto-delete · lifetime retention" else "Auto-delete after ${uiState.trashRetentionDays} days",
                onClick = { showTrashRetentionDialog = true }
            )
            
            SettingsClickableRow(
                icon = Icons.Default.Cloud,
                title = stringResource(R.string.cloud_usage),
                subtitle = stringResource(R.string.cloud_usage_subtitle, formatSize(uiState.totalStorageUsed)),
                onClick = onNavigateToCloudAnalysis
            )
            
            SettingsClickableRow(
                icon = Icons.Default.Storage,
                title = stringResource(R.string.internal_cache),
                subtitle = stringResource(R.string.internal_cache_subtitle, formatSize(uiState.internalCacheSize)),
                onClick = onNavigateToCacheDetails
            )

            SettingsClickableRow(
                icon = Icons.Default.Storage,
                title = stringResource(R.string.cache_size_limit),
                subtitle = if (uiState.cacheSizeLimit == 0L) stringResource(R.string.no_limit) else formatSize(uiState.cacheSizeLimit),
                onClick = { showCacheSizeDialog = true }
            )

            SettingsClickableRow(
                icon = Icons.Default.History,
                title = stringResource(R.string.media_age_limit),
                subtitle = formatCacheAge(uiState.cacheAgeLimit, context),
                onClick = { showCacheAgeDialog = true }
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            SettingsCategory(title = stringResource(R.string.backup_settings))
            SettingsToggleRow(
                icon = Icons.Default.Folder,
                title = stringResource(R.string.auto_backup),
                subtitle = if (isBackupWifiOnly && uiState.isAutoBackupEnabled) stringResource(R.string.waiting_for_wifi) else stringResource(R.string.backup_description),
                checked = uiState.isAutoBackupEnabled,
                onCheckedChange = onSetAutoBackupEnabled
            )
            SettingsToggleRow(
                icon = Icons.Default.Wifi,
                title = stringResource(R.string.backup_wifi_only),
                subtitle = stringResource(R.string.backup_wifi_only_desc),
                checked = isBackupWifiOnly,
                enabled = uiState.isAutoBackupEnabled,
                onCheckedChange = onSetBackupWifiOnly
            )
            SettingsClickableRow(
                icon = Icons.Default.Folder,
                title = stringResource(R.string.backup_folders),
                subtitle = stringResource(R.string.backup_folders_desc),
                onClick = onNavigateToBackupFolders
            )
            if (uiState.lastBackupTime > 0) {
                val date = Date(uiState.lastBackupTime)
                val format = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
                SettingsRow(
                    icon = Icons.Default.History,
                    title = stringResource(R.string.last_backup, format.format(date))
                )
            }
            SettingsClickableRow(
                icon = Icons.Default.CloudUpload,
                title = stringResource(R.string.backup_now),
                onClick = onTriggerManualBackup
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            SettingsCategory(title = stringResource(R.string.downloads))
            
            val downloadPath = if (uiState.downloadUri.isNullOrEmpty()) {
                stringResource(R.string.download_location_desc)
            } else {
                android.net.Uri.parse(uiState.downloadUri).path?.substringAfterLast(':') ?: uiState.downloadUri
            }
            
            SettingsClickableRow(
                icon = Icons.Default.FolderOpen,
                title = stringResource(R.string.download_location),
                subtitle = downloadPath,
                onClick = { 
                    folderLauncher.launch(null)
                }
            )
            if (!uiState.downloadUri.isNullOrEmpty()) {
                TextButton(
                    onClick = { onSetDownloadUri(null) },
                    modifier = Modifier.padding(horizontal = 16.dp)
                ) {
                    Text(stringResource(R.string.reset_to_default))
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            SettingsCategory(title = stringResource(R.string.metadata_backup))
            SettingsClickableRow(
                icon = Icons.Default.CloudUpload,
                title = stringResource(R.string.export_metadata),
                subtitle = stringResource(R.string.metadata_backup_desc),
                onClick = onExportMetadata
            )
            SettingsClickableRow(
                icon = Icons.Default.CloudUpload,
                title = stringResource(R.string.backup_metadata_cloud),
                subtitle = stringResource(R.string.backup_metadata_cloud_desc),
                onClick = onManualCloudBackup
            )
            SettingsClickableRow(
                icon = Icons.Default.CloudUpload,
                title = stringResource(R.string.import_metadata),
                subtitle = stringResource(R.string.import_confirm_message),
                onClick = { showImportConfirm = true }
            )
            
            SettingsClickableRow(
                icon = Icons.Default.History,
                title = stringResource(R.string.restore_from_cloud),
                subtitle = stringResource(R.string.cloud_backups_desc),
                onClick = { 
                    onLoadCloudBackups()
                    showCloudBackupsDialog = true 
                }
            )

            Text(
                text = stringResource(R.string.metadata_sync_info),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.outline,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            SettingsCategory(title = stringResource(R.string.system))
            
            SettingsClickableRow(
                icon = Icons.Default.Description,
                title = stringResource(R.string.app_logs),
                subtitle = stringResource(R.string.app_logs_desc),
                onClick = onNavigateToLogs
            )

            SettingsClickableRow(
                icon = Icons.Default.Info,
                title = stringResource(R.string.about_app),
                subtitle = "v${uiState.versionName} (${uiState.versionCode})",
                onClick = onNavigateToAbout
            )

            if (showCloudBackupsDialog) {
                AlertDialog(
                    onDismissRequest = { showCloudBackupsDialog = false },
                    title = { Text(stringResource(R.string.cloud_backups)) },
                    text = {
                        if (cloudBackups.isEmpty()) {
                            Text(stringResource(R.string.no_backups_found), modifier = Modifier.padding(16.dp))
                        } else {
                            LazyColumn(modifier = Modifier.heightIn(max = 400.dp)) {
                                items(cloudBackups) { backup ->
                                    val dateStr = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(backup.date))
                                    ListItem(
                                        headlineContent = { Text(dateStr) },
                                        supportingContent = { Text(stringResource(R.string.items_count, backup.folderCount)) },
                                        trailingContent = {
                                            TextButton(onClick = {
                                                onRestoreCloudBackup(backup.messageId)
                                                showCloudBackupsDialog = false
                                            }) {
                                                Text(stringResource(R.string.restore))
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showCloudBackupsDialog = false }) { Text(stringResource(R.string.cancel)) }
                    }
                )
            }

            if (showImportConfirm) {
                AlertDialog(
                    onDismissRequest = { showImportConfirm = false },
                    title = { Text(stringResource(R.string.import_confirm_title)) },
                    text = { Text(stringResource(R.string.import_confirm_message)) },
                    confirmButton = {
                        TextButton(onClick = {
                            showImportConfirm = false
                            onImportMetadata()
                        }) { Text(stringResource(R.string.confirm)) }
                    },
                    dismissButton = {
                        TextButton(onClick = { showImportConfirm = false }) { Text(stringResource(R.string.cancel)) }
                    }
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            ListItem(
                headlineContent = { 
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(stringResource(R.string.logout), color = MaterialTheme.colorScheme.error) 
                    }
                },
                modifier = Modifier.clickable { showLogoutConfirm = true }
            )
            
    Spacer(modifier = Modifier.height(64.dp))
        }
    }
}

@Preview(showBackground = true)
@Composable
fun SettingsPreview() {
    TeledriveTheme {
        SettingsContent(
            uiState = SettingsUiState(
                isDarkMode = false,
                themeColor = Color(0xFF24A1DE),
                backgroundColor = null,
                isSecurityEnabled = true,
                isPasswordSet = true,
                isBiometricEnabled = true,
                backgroundImageUri = null,
                apiId = "36619703",
                apiHash = "febf26de7c55c24412a8d7be390a759c",
                totalStorageUsed = 1024 * 1024 * 100,
                internalCacheSize = 1024 * 1024 * 50,
                cacheSizeLimit = 512 * 1024 * 1024L,
                cacheAgeLimit = 30 * 24 * 60 * 60,
                trashRetentionDays = -1,
                isAutoBackupEnabled = true,
                lastBackupTime = System.currentTimeMillis(),
                currentLanguage = "en",
                downloadUri = null,
                versionName = "1.1.0",
                versionCode = 2L,
                updateState = UpdateState.Idle
            ),
            isThumbnailAutoDownloadEnabled = true,
            isBackupWifiOnly = true,
            showCacheWarning = false,
            onBack = {},
            onLogout = {},
            onNavigateToBackupFolders = {},
            onNavigateToTrash = {},
            onNavigateToCacheDetails = {},
            onNavigateToCloudAnalysis = {},
            onNavigateToAbout = {},
            onSetDarkMode = {},
            onSetThemeColor = {},
            onSetBackgroundColor = {},
            onSetSecurityEnabled = {},
            onSetMasterPassword = { true },
            onTakePendingRecoveryCode = { null },
            onChangeMasterPassword = { _, _ -> true },
            onCreateRecoveryCode = { "ABCD-EFGH-JKLM-NPQR" },
            onSetBiometricEnabled = {},
            onSaveApiCredentials = { _, _ -> },
            onSetBackgroundImage = {},
            onSetAutoBackupEnabled = {},
            onSetBackupWifiOnly = {},
            onTriggerManualBackup = {},
            onNavigateToLogs = {},
            onClearCache = {},
            onSetLanguage = {},
            onSetDownloadUri = {},
            onSetCacheSizeLimit = {},
            onSetCacheAgeLimit = {},
            onSetTrashRetentionDays = {},
            onSetThumbnailAutoDownload = {},
            onDismissCacheWarning = {},
            onExportMetadata = {},
            onImportMetadata = {},
            onManualCloudBackup = {},
            cloudBackups = emptyList(),
            onLoadCloudBackups = {},
            onRestoreCloudBackup = {}
        )
    }
}

@Composable
fun SettingsCategory(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

@Composable
fun SettingsRow(icon: ImageVector, title: String, subtitle: String? = null) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = subtitle?.let { { Text(it) } },
        leadingContent = { Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) }
    )
}

@Composable
fun SettingsClickableRow(
    icon: ImageVector,
    title: String,
    subtitle: String? = null,
    showArrow: Boolean = true,
    onClick: () -> Unit
) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = subtitle?.let { { Text(it) } },
        leadingContent = { Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) },
        trailingContent = if (showArrow) {
            { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)) }
        } else null,
        modifier = Modifier.clickable(onClick = onClick)
    )
}

@Composable
fun SettingsToggleRow(
    icon: ImageVector,
    title: String,
    subtitle: String? = null,
    checked: Boolean,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit
) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = subtitle?.let { { Text(it) } },
        leadingContent = { Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) },
        trailingContent = {
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                enabled = enabled
            )
        },
        modifier = Modifier.clickable(enabled = enabled) { onCheckedChange(!checked) }
    )
}

private fun formatSize(size: Long): String {
    if (size <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(size.toDouble()) / Math.log10(1024.0)).toInt()
    return String.format(java.util.Locale.getDefault(), "%.1f %s", size / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
}

private fun formatCacheAge(seconds: Int, context: android.content.Context): String {
    return when (seconds) {
        0 -> context.getString(R.string.no_limit)
        7 * 24 * 60 * 60 -> "1 " + context.getString(R.string.week)
        30 * 24 * 60 * 60 -> "1 " + context.getString(R.string.month)
        90 * 24 * 60 * 60 -> "3 " + context.getString(R.string.months)
        365 * 24 * 60 * 60 -> "1 " + context.getString(R.string.year)
        else -> context.getString(R.string.seconds_label, seconds)
    }
}
