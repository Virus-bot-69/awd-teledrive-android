package com.awd.teledrive.ui.screens.settings

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import com.awd.teledrive.R
import com.awd.teledrive.data.worker.BackupFolderInfo
import com.awd.teledrive.ui.theme.TeledriveTheme
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupSettingsScreen(
    onBack: () -> Unit,
    viewModel: BackupViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val selectedFolders by viewModel.backupFolders.collectAsState()
    val availableFolders by viewModel.availableFolders.collectAsState()
    val isScanningFolders by viewModel.isScanningFolders.collectAsState()
    var hasStorageAccess by remember { mutableStateOf(viewModel.hasStorageAccess()) }
    val workInfoList by viewModel.backupWorkInfo.collectAsState(initial = emptyList())
    val activeWorkInfo = workInfoList.firstOrNull { it.state == androidx.work.WorkInfo.State.RUNNING }
        ?: workInfoList.firstOrNull { it.state == androidx.work.WorkInfo.State.ENQUEUED }

    val backupStartedMsg = stringResource(R.string.backup_started)
    val noFoldersMsg = stringResource(R.string.no_backup_folders)
    val accessRequiredMsg = stringResource(R.string.backup_storage_access_required)

    val settingsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        hasStorageAccess = viewModel.hasStorageAccess()
        viewModel.refreshBackupFolders()
    }

    val folderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        uri?.let { selectedUri ->
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    selectedUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            val path = filePathForTreeUri(selectedUri)
            if (path != null) {
                viewModel.addCustomBackupFolder(path)
            } else {
                Toast.makeText(context, context.getString(R.string.err_folder_path), Toast.LENGTH_LONG).show()
            }
        }
    }

    LaunchedEffect(Unit) {
        viewModel.refreshBackupFolders()
        viewModel.feedback.collect { feedback ->
            val message = when (feedback) {
                BackupFeedback.NoFolders -> noFoldersMsg
                BackupFeedback.StorageAccessRequired -> accessRequiredMsg
                BackupFeedback.Starting -> backupStartedMsg
            }
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }

    BackupSettingsContent(
        availableFolders = availableFolders,
        selectedFolders = selectedFolders,
        hasStorageAccess = hasStorageAccess,
        isScanningFolders = isScanningFolders,
        workInfo = activeWorkInfo,
        onBack = onBack,
        onToggleFolder = viewModel::toggleBackupFolder,
        onTriggerBackup = viewModel::triggerManualBackup,
        onPickCustomFolder = { folderPickerLauncher.launch(null) },
        onRequestStorageAccess = {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:${context.packageName}")
                )
            } else {
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
            }
            runCatching { settingsLauncher.launch(intent) }.onFailure {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    settingsLauncher.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
            }
        }
    )
}

private fun filePathForTreeUri(uri: Uri): String? = runCatching {
    val documentId = DocumentsContract.getTreeDocumentId(uri)
    val volume = documentId.substringBefore(':')
    val relativePath = documentId.substringAfter(':', "")
    val storageRoot = if (volume.equals("primary", ignoreCase = true)) {
        Environment.getExternalStorageDirectory()
    } else {
        File("/storage/$volume")
    }
    File(storageRoot, relativePath).canonicalPath
}.getOrNull()

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupSettingsContent(
    availableFolders: List<BackupFolderInfo>,
    selectedFolders: List<String>,
    hasStorageAccess: Boolean,
    isScanningFolders: Boolean,
    workInfo: androidx.work.WorkInfo?,
    onBack: () -> Unit,
    onToggleFolder: (String) -> Unit,
    onTriggerBackup: () -> Unit,
    onPickCustomFolder: () -> Unit,
    onRequestStorageAccess: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.backup_folders)) },
                modifier = Modifier.statusBarsPadding(),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.cancel))
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            workInfo?.let { info ->
                if (info.state == androidx.work.WorkInfo.State.RUNNING) {
                    val progress = info.progress.getFloat("progress", 0f)
                    val fileName = info.progress.getString("fileName") ?: ""
                    val current = info.progress.getInt("current", 0)
                    val total = info.progress.getInt("total", 0)
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (total > 0) stringResource(R.string.backing_up_files, current, total)
                                else stringResource(R.string.preparing),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "${(progress * 100).toInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                        )
                        if (fileName.isNotEmpty()) {
                            Text(fileName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                        }
                    }
                }
            }

            HorizontalDivider()

            if (!hasStorageAccess) {
                OutlinedCard(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.backup_storage_access_title),
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = stringResource(R.string.backup_storage_access_description),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Button(onClick = onRequestStorageAccess) {
                            Text(stringResource(R.string.backup_storage_access_button))
                        }
                    }
                }
                if (selectedFolders.isNotEmpty()) {
                    Text(
                        text = stringResource(R.string.backup_selected_folder_count, selectedFolders.size),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
                Spacer(Modifier.weight(1f))
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.backup_folders_desc),
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(
                        onClick = onPickCustomFolder,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(stringResource(R.string.add_folder), style = MaterialTheme.typography.labelMedium)
                    }
                }

                if (isScanningFolders) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text(
                        text = stringResource(R.string.backup_scanning_folders),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }

                val mediaFolders = availableFolders.filter { it.containsMedia }
                val otherFolders = availableFolders.filterNot { it.containsMedia }
                LazyColumn(modifier = Modifier.weight(1f)) {
                    if (mediaFolders.isNotEmpty()) {
                        item(key = "media_header") {
                            Text(
                                text = stringResource(R.string.backup_media_folders),
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                            )
                        }
                        items(mediaFolders, key = { it.path }) { folder ->
                            BackupFolderRow(folder, selectedFolders, onToggleFolder)
                        }
                    }
                    if (otherFolders.isNotEmpty()) {
                        item(key = "other_header") {
                            Text(
                                text = stringResource(R.string.backup_other_folders),
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                            )
                        }
                        items(otherFolders, key = { it.path }) { folder ->
                            BackupFolderRow(folder, selectedFolders, onToggleFolder)
                        }
                    }
                    if (availableFolders.isEmpty() && !isScanningFolders) {
                        item(key = "empty_folders") {
                            Text(
                                text = stringResource(R.string.backup_no_folders_found),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(20.dp)
                            )
                        }
                    }
                }
            }

            if (selectedFolders.isNotEmpty()) {
                Button(
                    onClick = onTriggerBackup,
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    shape = MaterialTheme.shapes.medium
                ) {
                    Text(stringResource(R.string.backup_now))
                }
            }
        }
    }
}

@Composable
private fun BackupFolderRow(
    folder: BackupFolderInfo,
    selectedFolders: List<String>,
    onToggleFolder: (String) -> Unit
) {
    val isSelected = folder.path in selectedFolders
    val folderName = File(folder.path).name.ifBlank { folder.path }
    ListItem(
        headlineContent = { Text(folderName) },
        supportingContent = { Text(folder.path, maxLines = 1) },
        leadingContent = {
            Icon(
                Icons.Default.Folder,
                contentDescription = null,
                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
            )
        },
        trailingContent = {
            Checkbox(checked = isSelected, onCheckedChange = { onToggleFolder(folder.path) })
        },
        modifier = Modifier.clickable { onToggleFolder(folder.path) }
    )
    HorizontalDivider()
}

@Preview(showBackground = true)
@Composable
fun BackupSettingsPreview() {
    TeledriveTheme {
        BackupSettingsContent(
            availableFolders = listOf(
                BackupFolderInfo("/storage/emulated/0/DCIM", containsMedia = true),
                BackupFolderInfo("/storage/emulated/0/Pictures", containsMedia = false)
            ),
            selectedFolders = listOf("/storage/emulated/0/DCIM"),
            hasStorageAccess = true,
            isScanningFolders = false,
            workInfo = null,
            onBack = {},
            onToggleFolder = {},
            onTriggerBackup = {},
            onPickCustomFolder = {},
            onRequestStorageAccess = {}
        )
    }
}
