package com.awd.teledrive.data.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Environment
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.awd.teledrive.R
import com.awd.teledrive.data.repository.DriveRepository
import com.awd.teledrive.data.secure.SecureSettings
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.ArrayDeque
import java.util.Locale

class MediaBackupWorker(
    context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    companion object {
        private const val NOTIFICATION_ID = 101
        private const val CHANNEL_ID = "backup_channel"
        private val backupMutex = Mutex()
        private val MEDIA_EXTENSIONS = setOf(
            "jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif", "avif", "dng", "tif", "tiff", "raw", "cr2", "nef", "arw",
            "mp4", "m4v", "mov", "mkv", "avi", "webm", "3gp", "3gpp", "3g2", "ts", "mts", "m2ts", "m2v", "mpg", "mpeg", "wmv", "flv",
            "mp3", "m4a", "aac", "wav", "ogg", "oga", "opus", "flac", "amr", "aiff", "mid", "midi", "wma", "mka"
        )
        private val SKIPPED_DIRECTORY_NAMES = setOf(
            ".thumbnails", ".cache", ".trash", "lost.dir", "system volume information", "\$recycle.bin"
        )
    }

    @EntryPoint
    @InstallIn(SingletonComponent::class)
    interface MediaBackupWorkerEntryPoint {
        fun driveRepository(): DriveRepository
        fun secureSettings(): SecureSettings
    }

    override suspend fun doWork(): Result = backupMutex.withLock {
        withContext(Dispatchers.IO) {
            try {
                setForeground(createForegroundInfo(0, 0))

                val entryPoint = EntryPointAccessors.fromApplication(
                    applicationContext,
                    MediaBackupWorkerEntryPoint::class.java
                )
                val driveRepository = entryPoint.driveRepository()
                val secureSettings = entryPoint.secureSettings()

                val backupFolders = secureSettings.getStringList("backup_folders")
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
                    .distinct()
                if (backupFolders.isEmpty()) return@withContext Result.success()

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
                    return@withContext Result.failure()
                }

                val scanStartedAt = System.currentTimeMillis()
                val filesToUpload = LinkedHashMap<String, File>()
                val timestampKeys = linkedSetOf<String>()

                backupFolders.forEach { folderPath ->
                    val root = File(folderPath)
                    if (!root.exists() || !root.isDirectory || !root.canRead()) return@forEach

                    val normalizedPath = canonicalPath(root)
                    val timestampKey = folderTimestampKey(normalizedPath)
                    val previousTimestamp = secureSettings.getLong(
                        timestampKey,
                        secureSettings.getLong("last_backup_time", 0L)
                    )
                    timestampKeys.add(timestampKey)
                    scanNewMedia(root, normalizedPath, previousTimestamp, filesToUpload)
                }

                val newMedia = filesToUpload.values.sortedBy { it.lastModified() }
                if (newMedia.isEmpty()) {
                    timestampKeys.forEach { secureSettings.saveLong(it, scanStartedAt) }
                    secureSettings.saveLong("last_backup_time", scanStartedAt)
                    return@withContext Result.success()
                }

                newMedia.forEachIndexed { index, file ->
                    val currentCount = index + 1
                    val totalCount = newMedia.size
                    setProgress(
                        workDataOf(
                            "progress" to index.toFloat() / totalCount,
                            "fileName" to file.name,
                            "current" to currentCount,
                            "total" to totalCount
                        )
                    )
                    setForeground(createForegroundInfo(currentCount, totalCount))
                    driveRepository.uploadFile(file.absolutePath, file.name)
                    delay(1500)
                }

                // Save the scan start time, not completion time, so media created during
                // the scan will still be picked up by the next observer/periodic pass.
                timestampKeys.forEach { secureSettings.saveLong(it, scanStartedAt) }
                secureSettings.saveLong("last_backup_time", scanStartedAt)
                Result.success()
            } catch (e: Exception) {
                Result.retry()
            }
        }
    }

    private fun scanNewMedia(
        root: File,
        rootPath: String,
        sinceTimestamp: Long,
        result: MutableMap<String, File>
    ) {
        val pending = ArrayDeque<File>()
        val visited = HashSet<String>()
        pending.addLast(root)

        while (pending.isNotEmpty()) {
            val directory = pending.removeLast()
            val directoryPath = canonicalPath(directory)
            if (!visited.add(directoryPath) || !isWithinRoot(directoryPath, rootPath)) continue

            val children = directory.listFiles() ?: continue
            for (child in children) {
                if (child.isDirectory) {
                    if (!shouldSkipTraversal(child)) pending.addLast(child)
                } else if (
                    child.isFile && child.lastModified() > sinceTimestamp && isSupportedMediaFile(child)
                ) {
                    val path = canonicalPath(child)
                    if (isWithinRoot(path, rootPath)) result.putIfAbsent(path, child)
                }
            }
        }
    }

    private fun shouldSkipTraversal(directory: File): Boolean {
        val name = directory.name.lowercase(Locale.ROOT)
        if (name in SKIPPED_DIRECTORY_NAMES) return true
        val parentName = directory.parentFile?.name?.lowercase(Locale.ROOT)
        return parentName == "android" && (name == "data" || name == "obb")
    }

    private fun isSupportedMediaFile(file: File): Boolean =
        file.extension.lowercase(Locale.ROOT) in MEDIA_EXTENSIONS

    private fun folderTimestampKey(path: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(path.toByteArray())
        val hash = digest.joinToString("") { byte -> "%02x".format(byte) }
        return "backup_folder_last_scan_$hash"
    }

    private fun isWithinRoot(path: String, root: String): Boolean =
        path == root || path.startsWith(root.trimEnd(File.separatorChar) + File.separator)

    private fun canonicalPath(file: File): String =
        runCatching { file.canonicalPath }.getOrElse { file.absolutePath }

    private fun createForegroundInfo(current: Int, total: Int): ForegroundInfo {
        createNotificationChannel()
        val title = applicationContext.getString(R.string.auto_backup)
        val content = if (total > 0) {
            applicationContext.getString(R.string.backing_up_media_count, current, total)
        } else {
            applicationContext.getString(R.string.scanning_media)
        }

        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setContentTitle(title)
            .setTicker(title)
            .setContentText(content)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .setProgress(total, current, total == 0)
            .build()

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = applicationContext.getString(R.string.auto_backup)
            val channel = NotificationChannel(CHANNEL_ID, name, NotificationManager.IMPORTANCE_LOW)
            val notificationManager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
}
