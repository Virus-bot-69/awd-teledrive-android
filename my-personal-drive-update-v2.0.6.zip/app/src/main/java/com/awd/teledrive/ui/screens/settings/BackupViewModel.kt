package com.awd.teledrive.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.awd.teledrive.data.repository.SettingsRepository
import com.awd.teledrive.data.secure.SecureSettings
import com.awd.teledrive.data.worker.BackupFolderInfo
import com.awd.teledrive.data.worker.BackupFolderScanner
import com.awd.teledrive.data.worker.TeleDriveWorkerManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import javax.inject.Inject

sealed class BackupFeedback {
    object NoFolders : BackupFeedback()
    object StorageAccessRequired : BackupFeedback()
    object Starting : BackupFeedback()
}

@HiltViewModel
class BackupViewModel @Inject constructor(
    private val secureSettings: SecureSettings,
    private val settingsRepository: SettingsRepository,
    private val workerManager: TeleDriveWorkerManager,
    private val backupFolderScanner: BackupFolderScanner
) : ViewModel() {

    val isAutoBackupEnabled = settingsRepository.isAutoBackupEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    private val _lastBackupTime = MutableStateFlow(secureSettings.getLong("last_backup_time", 0L))
    val lastBackupTime = _lastBackupTime.asStateFlow()

    private val _backupFolders = MutableStateFlow(secureSettings.getStringList("backup_folders"))
    val backupFolders = _backupFolders.asStateFlow()

    private val _availableFolders = MutableStateFlow<List<BackupFolderInfo>>(emptyList())
    val availableFolders = _availableFolders.asStateFlow()

    private val _isScanningFolders = MutableStateFlow(false)
    val isScanningFolders = _isScanningFolders.asStateFlow()

    private val _feedback = MutableSharedFlow<BackupFeedback>()
    val feedback: SharedFlow<BackupFeedback> = _feedback.asSharedFlow()

    val isBackupWifiOnly = settingsRepository.isBackupWifiOnlyEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val backupWorkInfo = workerManager.getBackupWorkInfo()
    private var folderScanJob: Job? = null

    fun hasStorageAccess(): Boolean = backupFolderScanner.hasStorageAccess()

    /** Refresh both persisted selection and the device folder list when returning to this screen. */
    fun refreshBackupFolders() {
        val saved = readSavedFolders()
        _backupFolders.value = saved

        folderScanJob?.cancel()
        if (!backupFolderScanner.hasStorageAccess()) {
            _availableFolders.value = saved.map { BackupFolderInfo(it, containsMedia = false) }
            _isScanningFolders.value = false
            return
        }
        if (secureSettings.getBoolean("auto_backup_enabled", false) && saved.isNotEmpty()) {
            workerManager.scheduleBackup(true)
        }

        folderScanJob = viewModelScope.launch {
            _isScanningFolders.value = true
            try {
                val discovered = withContext(Dispatchers.IO) { backupFolderScanner.scanFolders() }
                val latestSaved = readSavedFolders()
                _backupFolders.value = latestSaved
                val discoveredPaths = discovered.mapTo(mutableSetOf()) { it.path }
                val previouslySelectedButUnlisted = latestSaved
                    .filterNot { it in discoveredPaths }
                    .map { BackupFolderInfo(it, containsMedia = false) }
                _availableFolders.value = (discovered + previouslySelectedButUnlisted)
                    .distinctBy { it.path }
                    .sortedWith(
                        compareByDescending<BackupFolderInfo> { it.containsMedia }
                            .thenBy { File(it.path).name.lowercase(Locale.ROOT) }
                            .thenBy { it.path.lowercase(Locale.ROOT) }
                    )
            } finally {
                _isScanningFolders.value = false
            }
        }
    }

    fun setAutoBackupEnabled(enabled: Boolean) {
        if (enabled) {
            val saved = readSavedFolders()
            _backupFolders.value = saved
            if (saved.isEmpty()) {
                viewModelScope.launch { _feedback.emit(BackupFeedback.NoFolders) }
                return
            }
            if (!backupFolderScanner.hasStorageAccess()) {
                viewModelScope.launch { _feedback.emit(BackupFeedback.StorageAccessRequired) }
                return
            }
        }
        settingsRepository.setAutoBackupEnabled(enabled)
        workerManager.scheduleBackup(enabled)
    }

    fun setBackupWifiOnly(enabled: Boolean) {
        settingsRepository.setBackupWifiOnlyEnabled(enabled)
        if (isAutoBackupEnabled.value) workerManager.scheduleBackup(true)
    }

    fun toggleBackupFolder(path: String) {
        val current = readSavedFolders().toMutableList()
        if (path in current) current.remove(path) else current.add(path)
        saveFolders(current)
    }

    fun addCustomBackupFolder(path: String) {
        if (path.isBlank()) return
        val current = readSavedFolders().toMutableList()
        if (path !in current) current.add(path)
        saveFolders(current)
        refreshBackupFolders()
    }

    fun triggerManualBackup() {
        val saved = readSavedFolders()
        _backupFolders.value = saved
        if (saved.isEmpty()) {
            viewModelScope.launch { _feedback.emit(BackupFeedback.NoFolders) }
            return
        }
        if (!backupFolderScanner.hasStorageAccess()) {
            viewModelScope.launch { _feedback.emit(BackupFeedback.StorageAccessRequired) }
            return
        }
        viewModelScope.launch { _feedback.emit(BackupFeedback.Starting) }
        workerManager.triggerOneTimeBackup()
    }

    private fun readSavedFolders(): List<String> = secureSettings.getStringList("backup_folders")
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .distinct()

    private fun saveFolders(folders: List<String>) {
        val unique = folders.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        _backupFolders.value = unique
        secureSettings.saveStringList("backup_folders", unique)
    }
}
