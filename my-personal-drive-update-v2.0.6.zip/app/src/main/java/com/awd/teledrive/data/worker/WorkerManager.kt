package com.awd.teledrive.data.worker

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.awd.teledrive.data.secure.SecureSettings
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.combine
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TeleDriveWorkerManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val secureSettings: SecureSettings
) {
    fun scheduleBackup(enabled: Boolean) {
        try {
            val workManager = WorkManager.getInstance(context)
            if (!enabled) {
                workManager.cancelUniqueWork(BACKUP_PERIODIC_WORK_NAME)
                workManager.cancelUniqueWork(BACKUP_ON_DEMAND_WORK_NAME)
                return
            }

            val isWifiOnly = secureSettings.getBoolean("backup_wifi_only", true)
            val networkType = if (isWifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED
            val backupRequest = PeriodicWorkRequestBuilder<MediaBackupWorker>(15, TimeUnit.MINUTES)
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(networkType)
                        .build()
                )
                .build()

            workManager.enqueueUniquePeriodicWork(
                BACKUP_PERIODIC_WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                backupRequest
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /** Manual Backup Now works whether Auto Backup is enabled or not. */
    fun triggerOneTimeBackup() = enqueueOnDemandBackup()

    /** Called after MediaStore reports a new or changed media item. */
    fun triggerAutomaticBackup() = enqueueOnDemandBackup()

    private fun enqueueOnDemandBackup() {
        try {
            val isWifiOnly = secureSettings.getBoolean("backup_wifi_only", true)
            val networkType = if (isWifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED
            val backupRequest = OneTimeWorkRequestBuilder<MediaBackupWorker>()
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(networkType)
                        .build()
                )
                .build()

            WorkManager.getInstance(context).enqueueUniqueWork(
                BACKUP_ON_DEMAND_WORK_NAME,
                ExistingWorkPolicy.APPEND_OR_REPLACE,
                backupRequest
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun scheduleCoreRefresh() {
        val refreshRequest = PeriodicWorkRequestBuilder<BackupWorker>(6, TimeUnit.HOURS)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "core_refresh_worker",
            ExistingPeriodicWorkPolicy.KEEP,
            refreshRequest
        )
    }

    fun getBackupWorkInfo(): kotlinx.coroutines.flow.Flow<List<WorkInfo>> {
        val workManager = WorkManager.getInstance(context)
        return combine(
            workManager.getWorkInfosForUniqueWorkFlow(BACKUP_PERIODIC_WORK_NAME),
            workManager.getWorkInfosForUniqueWorkFlow(BACKUP_ON_DEMAND_WORK_NAME)
        ) { periodic, onDemand ->
            (onDemand + periodic).distinctBy { it.id }
        }
    }

    companion object {
        private const val BACKUP_PERIODIC_WORK_NAME = "media_backup_worker"
        private const val BACKUP_ON_DEMAND_WORK_NAME = "media_backup_on_demand"
    }
}
