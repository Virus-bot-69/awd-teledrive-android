package com.awd.teledrive.ui.screens.accounts

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import com.awd.teledrive.R
import com.awd.teledrive.data.account.AccountEntry
import com.awd.teledrive.core.Config
import org.drinkless.tdlib.TdApi
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Account manager: several Telegram accounts (each with its own TDLib database) plus a
 * Google account for the Multi Drive tab. Switching relaunches the app so no cached
 * state from the previous account survives.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountsScreen(
    onBack: () -> Unit,
    viewModel: AccountsViewModel = hiltViewModel()
) {
    val accounts by viewModel.accounts.collectAsState()
    val activeTelegramId by viewModel.activeTelegramId.collectAsState()
    val activeGoogleId by viewModel.activeGoogleId.collectAsState()
    val busy by viewModel.busy.collectAsState()
    val message by viewModel.message.collectAsState()

    val context = LocalContext.current
    var showAddDialog by remember { mutableStateOf(false) }
    var newLabel by remember { mutableStateOf("") }
    var confirmRemove by remember { mutableStateOf<AccountEntry?>(null) }
    var showLinkedSessions by remember { mutableStateOf(false) }
    var sessionToRevoke by remember { mutableStateOf<TdApi.Session?>(null) }
    val sessions by viewModel.sessions.collectAsState()
    val sessionsLoading by viewModel.sessionsLoading.collectAsState()
    val sessionsError by viewModel.sessionsError.collectAsState()

    val telegramAccounts = accounts.filter { it.isTelegram }
    val googleAccounts = accounts.filter { it.isGoogle }
    val googleEmail by viewModel.googleEmail.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Accounts") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Add account") }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            if (busy) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            if (message != null) {
                Text(
                    text = message ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(
                        "Telegram accounts",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        "Each account keeps its own TDLib database, so switching is instant and never mixes data.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                items(telegramAccounts) { account ->
                    val phoneKey = account.detail.filter(Char::isDigit).removePrefix("00")
                    val duplicateNumber = phoneKey.length >= 5 && telegramAccounts.count {
                        it.detail.filter(Char::isDigit).removePrefix("00") == phoneKey
                    } > 1
                    val accountStatus = when {
                        duplicateNumber -> "Duplicate number"
                        account.detail.isBlank() -> "Not signed in"
                        else -> "Signed in"
                    }
                    val subtitle = listOfNotNull(
                        account.detail.ifBlank { null },
                        accountStatus,
                        if (account.id == activeTelegramId) "Active" else "Tap to switch"
                    ).joinToString(" · ")
                    AccountRow(
                        title = viewModel.labelFor(account),
                        subtitle = subtitle,
                        active = account.id == activeTelegramId,
                        canDelete = telegramAccounts.size > 1,
                        onClick = { if (account.id != activeTelegramId) viewModel.switchAccount(account) },
                        onDelete = { confirmRemove = account }
                    )
                }

                item {
                    OutlinedButton(
                        onClick = {
                            showLinkedSessions = true
                            viewModel.refreshSessions()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(stringResource(R.string.manage_linked_devices)) }
                }

                item {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Google account (Multi Drive)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        "Google allows one active Drive session at a time. Signing in again replaces it.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                item {
                    if (googleEmail == null) {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                            )
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                Text("No Google account connected", fontWeight = FontWeight.Medium)
                                if (!Config.isGoogleConfigured) {
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        "Google sign-in needs your Google Android OAuth client ID. Create it in Google Cloud and rebuild the APK; the button is disabled until then.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Spacer(Modifier.height(8.dp))
                                Button(
                                    enabled = Config.isGoogleConfigured,
                                    onClick = {
                                        val url = viewModel.googleSignInUrl()
                                        if (url != null) {
                                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                        }
                                    }
                                ) { Text("Sign in with Google") }
                            }
                        }
                    } else {
                        AccountRow(
                            title = googleEmail.orEmpty(),
                            subtitle = "Connected · Google Drive",
                            active = true,
                            canDelete = true,
                            onClick = {},
                            onDelete = { viewModel.googleSignOut() }
                        )
                    }
                }
                item { Spacer(Modifier.height(70.dp)) }
            }
        }
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Telegram account") },
            text = {
                Column {
                    Text(
                        "A separate account slot is created on this device. For the same Telegram account on a second device, start My Personal Drive there and use its QR login; approve it from a Telegram device already signed in to that account.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = newLabel,
                        onValueChange = { newLabel = it },
                        label = { Text("Label (optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showAddDialog = false
                    viewModel.addTelegramAccount(newLabel)
                    newLabel = ""
                }) { Text("Create & restart") }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("Cancel") }
            }
        )
    }

    confirmRemove?.let { account ->
        AlertDialog(
            onDismissRequest = { confirmRemove = null },
            title = { Text("Remove account?") },
            text = {
                Text(
                    "The local TDLib data of this slot is deleted from this device. " +
                        "Your files stay safe in the cloud — only the session is removed."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.removeAccount(account)
                    confirmRemove = null
                }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { confirmRemove = null }) { Text("Cancel") } }
        )
    }

    if (showLinkedSessions) {
        AlertDialog(
            onDismissRequest = { showLinkedSessions = false },
            title = { Text(stringResource(R.string.linked_devices_title)) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        stringResource(R.string.linked_devices_description),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (sessionsLoading) {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                    sessionsError?.let { error ->
                        Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                    if (!sessionsLoading && sessions.isEmpty() && sessionsError == null) {
                        Text(stringResource(R.string.no_linked_devices), style = MaterialTheme.typography.bodySmall)
                    }
                    sessions.forEach { session ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        session.deviceModel.ifBlank { session.applicationName.ifBlank { "Telegram device" } },
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        listOf(session.platform, session.systemVersion)
                                            .filter { it.isNotBlank() }.joinToString(" · "),
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Text(
                                        if (session.isCurrent) stringResource(R.string.current_device)
                                        else stringResource(R.string.last_active, formatSessionTimestamp(session.lastActiveDate)),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (!session.isCurrent) {
                                    TextButton(onClick = {
                                        sessionToRevoke = session
                                        showLinkedSessions = false
                                    }) {
                                        Text(stringResource(R.string.revoke_device))
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLinkedSessions = false }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }

    sessionToRevoke?.let { session ->
        AlertDialog(
            onDismissRequest = {
                sessionToRevoke = null
                showLinkedSessions = true
            },
            title = { Text(stringResource(R.string.revoke_device_title)) },
            text = {
                Text(
                    "${session.deviceModel} · ${session.platform}\n" +
                        stringResource(R.string.revoke_device_message)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.terminateSession(session.id)
                    sessionToRevoke = null
                    showLinkedSessions = true
                }) { Text(stringResource(R.string.revoke_device)) }
            },
            dismissButton = {
                TextButton(onClick = {
                    sessionToRevoke = null
                    showLinkedSessions = true
                }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }
}

private fun formatSessionTimestamp(timestamp: Int): String {
    if (timestamp <= 0) return "Unknown"
    return SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(timestamp.toLong() * 1000L))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AccountRow(
    title: String,
    subtitle: String,
    active: Boolean,
    canDelete: Boolean,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(
            containerColor = if (active) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
        )
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (active) Icons.Default.CheckCircle else Icons.Default.Person,
                contentDescription = null,
                tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(24.dp)
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Medium)
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (canDelete) {
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Remove", modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}
