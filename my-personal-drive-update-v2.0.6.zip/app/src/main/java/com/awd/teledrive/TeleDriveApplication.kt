package com.awd.teledrive

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import com.awd.teledrive.data.worker.MediaBackupObserver
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class TeleDriveApplication : Application(), ImageLoaderFactory {
    @Inject lateinit var mediaBackupObserver: MediaBackupObserver

    override fun onCreate() {
        super.onCreate()
        mediaBackupObserver.start()
    }

    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .components {
                add(VideoFrameDecoder.Factory())
            }
            .crossfade(true)
            .build()
    }
}
