package com.awd.teledrive.data.worker

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import androidx.core.content.ContextCompat
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.util.ArrayDeque
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

data class BackupFolderInfo(
    val path: String,
    val containsMedia: Boolean
)

/** Lists storage folders after the user grants Android's broad file-access permission. */
@Singleton
class BackupFolderScanner @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        private const val MAX_SCANNED_DIRECTORIES = 20_000
        private const val MAX_DIRECTORY_DEPTH = 32
        private val MEDIA_EXTENSIONS = setOf(
            "jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif", "avif", "dng", "tif", "tiff", "raw", "cr2", "nef", "arw",
            "mp4", "m4v", "mov", "mkv", "avi", "webm", "3gp", "3gpp", "3g2", "ts", "mts", "m2ts", "m2v", "mpg", "mpeg", "wmv", "flv",
            "mp3", "m4a", "aac", "wav", "ogg", "oga", "opus", "flac", "amr", "aiff", "mid", "midi", "wma", "mka"
        )
        private val SKIPPED_DIRECTORY_NAMES = setOf(
            ".thumbnails", ".cache", ".trash", "lost.dir", "system volume information", "\$recycle.bin"
        )
    }

    fun hasStorageAccess(): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else {
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED
    }

    fun scanFolders(): List<BackupFolderInfo> {
        if (!hasStorageAccess()) return emptyList()

        val roots = storageRoots()
        if (roots.isEmpty()) return emptyList()
        val rootPaths = roots.mapTo(mutableSetOf()) { canonicalPath(it) }
        val directories = LinkedHashMap<String, File>()
        val mediaDirectories = HashSet<String>()
        val visited = HashSet<String>()
        val queue = ArrayDeque<Pair<File, Int>>()
        roots.forEach { queue.addLast(it to 0) }
        var visitedCount = 0

        while (queue.isNotEmpty() && visitedCount < MAX_SCANNED_DIRECTORIES) {
            val (directory, depth) = queue.removeFirst()
            val directoryPath = canonicalPath(directory)
            if (!visited.add(directoryPath)) continue
            visitedCount++

            val children = directory.listFiles()?.sortedBy { it.name.lowercase(Locale.ROOT) } ?: continue
            for (child in children) {
                if (child.isDirectory) {
                    if (shouldSkipTraversal(child)) continue
                    val childPath = canonicalPath(child)
                    if (childPath !in rootPaths) directories.putIfAbsent(childPath, child)
                    if (depth < MAX_DIRECTORY_DEPTH) queue.addLast(child to depth + 1)
                } else if (child.isFile && isSupportedMediaFile(child)) {
                    var parent = child.parentFile
                    while (parent != null) {
                        val parentPath = canonicalPath(parent)
                        if (parentPath in rootPaths) break
                        mediaDirectories.add(parentPath)
                        parent = parent.parentFile
                    }
                }
            }
        }

        return directories.map { (path, _) ->
            BackupFolderInfo(path, path in mediaDirectories)
        }.sortedWith(
            compareByDescending<BackupFolderInfo> { it.containsMedia }
                .thenBy { File(it.path).name.lowercase(Locale.ROOT) }
                .thenBy { it.path.lowercase(Locale.ROOT) }
        )
    }

    private fun storageRoots(): List<File> {
        val candidates = linkedSetOf<File>()
        candidates.add(Environment.getExternalStorageDirectory())

        context.getExternalFilesDirs(null).filterNotNull().forEach { appFilesDirectory ->
            val path = appFilesDirectory.absolutePath
            val marker = "/Android/data/"
            val markerIndex = path.indexOf(marker, ignoreCase = true)
            if (markerIndex > 0) candidates.add(File(path.substring(0, markerIndex)))
        }

        return candidates.asSequence()
            .map { File(canonicalPath(it)) }
            .filter { it.exists() && it.isDirectory && it.canRead() }
            .distinctBy { canonicalPath(it) }
            .toList()
    }

    private fun shouldSkipTraversal(directory: File): Boolean {
        val name = directory.name.lowercase(Locale.ROOT)
        if (name in SKIPPED_DIRECTORY_NAMES) return true
        val parentName = directory.parentFile?.name?.lowercase(Locale.ROOT)
        return parentName == "android" && (name == "data" || name == "obb")
    }

    private fun isSupportedMediaFile(file: File): Boolean =
        file.extension.lowercase(Locale.ROOT) in MEDIA_EXTENSIONS

    private fun canonicalPath(file: File): String =
        runCatching { file.canonicalPath }.getOrElse { file.absolutePath }
}
