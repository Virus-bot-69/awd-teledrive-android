package com.awd.teledrive.data.worker

import android.content.Context
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import com.awd.teledrive.data.secure.SecureSettings
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Watches MediaStore while the app process is alive and queues a debounced backup run.
 * Periodic WorkManager work remains as a fallback for changes missed while the process is stopped.
 */
@Singleton
class MediaBackupObserver @Inject constructor(
    @ApplicationContext private val context: Context,
    private val secureSettings: SecureSettings,
    private val backupFolderScanner: BackupFolderScanner,
    private val workerManager: TeleDriveWorkerManager
) {
    private val handler = Handler(Looper.getMainLooper())
    private var registered = false
    private var pendingBackup: Runnable? = null

    private val observer = object : ContentObserver(handler) {
        override fun onChange(selfChange: Boolean, uri: Uri?) {
            scheduleBackupIfConfigured()
        }
    }

    @Synchronized
    fun start() {
        if (registered) return
        val resolver = context.contentResolver
        listOf(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        ).forEach { uri ->
            resolver.registerContentObserver(uri, true, observer)
        }
        registered = true

        // Refresh the cadence/constraints of any periodic work created by an older app version.
        if (secureSettings.getBoolean("auto_backup_enabled", false) &&
            secureSettings.getStringList("backup_folders").isNotEmpty() &&
            backupFolderScanner.hasStorageAccess()
        ) {
            workerManager.scheduleBackup(true)
        }
    }

    private fun scheduleBackupIfConfigured() {
        if (!secureSettings.getBoolean("auto_backup_enabled", false)) return
        if (secureSettings.getStringList("backup_folders").isEmpty()) return
        if (!backupFolderScanner.hasStorageAccess()) return

        synchronized(this) {
            pendingBackup?.let { handler.removeCallbacks(it) }
            val next = Runnable {
                if (secureSettings.getBoolean("auto_backup_enabled", false) &&
                    secureSettings.getStringList("backup_folders").isNotEmpty() &&
                    backupFolderScanner.hasStorageAccess()
                ) {
                    workerManager.triggerAutomaticBackup()
                }
            }
            pendingBackup = next
            handler.postDelayed(next, DEBOUNCE_MILLIS)
        }
    }

    companion object {
        private const val DEBOUNCE_MILLIS = 3_000L
    }
}
