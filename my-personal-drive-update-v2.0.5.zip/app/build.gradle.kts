plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.hilt)
    alias(libs.plugins.legacy.kapt)
    alias(libs.plugins.kotlin.serialization)
}

// One client id feeds both BuildConfig (OAuth requests) and the manifest redirect scheme.
// Precedence: explicit Gradle property -> GitHub Actions env/input -> source default in Config.kt.
val sourceGoogleClientId = runCatching {
    val configText = file("src/main/java/com/awd/teledrive/core/Config.kt").readText()
    Regex("const\\s+val\\s+GOOGLE_CLIENT_ID_DEFAULT\\s*:\\s*String\\s*=\\s*\"([^\"]*)\"")
        .find(configText)?.groupValues?.getOrNull(1).orEmpty()
}.getOrDefault("")
val googleClientIdForBuild = providers.gradleProperty("GOOGLE_CLIENT_ID").orNull?.takeIf { it.isNotBlank() }
    ?: System.getenv("GOOGLE_CLIENT_ID")?.takeIf { it.isNotBlank() }
    ?: sourceGoogleClientId
val escapedGoogleClientId = googleClientIdForBuild.replace("\\", "\\\\").replace("\"", "\\\"")

android {
    namespace = "com.awd.teledrive"
    compileSdk = 37

    signingConfigs {
        create("release") {
            // Membaca dari Environment Variables yang disiapkan oleh GitHub Actions
            val keystorePath = System.getenv("KEYSTORE_PATH")
            if (keystorePath != null && file(keystorePath).exists()) {
                storeFile = file(keystorePath)
                storePassword = System.getenv("KEY_STORE_PASSWORD")
                keyAlias = System.getenv("ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    defaultConfig {
        applicationId = "com.awd.teledrive"
        minSdk = 24
        targetSdk = 35
        versionCode = 13
        versionName = "2.0.5"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        buildConfigField("String", "GOOGLE_CLIENT_ID", "\"$escapedGoogleClientId\"")

        // Keep the OAuth callback scheme in sync with the client ID compiled into the app.
        manifestPlaceholders["appAuthRedirectScheme"] =
            if (googleClientIdForBuild.isNotBlank() && googleClientIdForBuild.contains(".apps.googleusercontent.com"))
                "com.googleusercontent.apps." + googleClientIdForBuild.substringBefore(".apps.googleusercontent.com")
            else "com.awd.teledrive.oauth"

        // Hanya sertakan arsitektur yang umum digunakan untuk mengurangi ukuran APK
        ndk {
            abiFilters.addAll(listOf("arm64-v8a", "armeabi-v7a"))
        }
    }

    splits {
        abi {
            isEnable = true
            reset()
            include("arm64-v8a", "armeabi-v7a")
            isUniversalApk = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            
            // Gunakan konfigurasi signing release jika tersedia dan valid
            val releaseSigning = signingConfigs.findByName("release")
            if (releaseSigning != null && releaseSigning.storeFile != null) {
                signingConfig = releaseSigning
            }

            // Tambahkan optimasi tambahan
            ndk {
                debugSymbolLevel = "none"
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        jniLibs {
            useLegacyPackaging = false
        }
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "META-INF/DEPENDENCIES"
            excludes += "META-INF/LICENSE*"
            excludes += "META-INF/NOTICE*"
            excludes += "META-INF/ASL2.0"
            excludes += "META-INF/*.kotlin_module"
        }
    }
}

// Kustomisasi Nama APK Output
androidComponents {
    onVariants { variant ->
        variant.outputs.forEach { output ->
            val abi = output.filters.find { it.filterType == com.android.build.api.variant.FilterConfiguration.FilterType.ABI }?.identifier ?: "universal"
            (output as? com.android.build.api.variant.impl.VariantOutputImpl)?.outputFileName?.set("my-personal-drive-v${android.defaultConfig.versionName}-$abi-${variant.name}.apk")
        }
    }
}

kapt {
    correctErrorTypes = true
}

dependencies {
    implementation(libs.androidx.appcompat)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    implementation(libs.androidx.compose.ui)

    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.hilt.android)
    kapt(libs.hilt.compiler)
    implementation(libs.androidx.hilt.navigation.compose)

    // Telegram and Security
    implementation(libs.tdlibx)
    implementation(libs.lazysodium.android)
    implementation(libs.jna)

    // Media & Image
    implementation(libs.coilCompose)
    implementation(libs.coilVideo)
    implementation(libs.media3Exoplayer)
    implementation(libs.media3Ui)

    // Room & SQLite
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    kapt(libs.androidx.room.compiler)
    implementation(libs.sqlcipher)

    // Security & Crypto
    implementation(libs.androidx.security.crypto)
    implementation(libs.argon2kt)
    implementation(libs.androidx.biometric)
    implementation(libs.androidx.documentfile)

    // WorkManager
    implementation(libs.androidx.work.runtime.ktx)

    // Kotlin Serialization
    implementation(libs.kotlinx.serialization.json)

    // Local QR rendering for Telegram's native, short-lived device-link login.
    implementation("com.google.zxing:core:3.5.3")

    testImplementation(libs.junit)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(libs.androidx.junit)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
    debugImplementation(libs.androidx.compose.ui.tooling)
}

