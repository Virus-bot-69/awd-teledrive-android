package com.awd.teledrive.ui.components

import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Renders a transient QR locally; the login token is never saved or logged by this view. */
@Composable
fun QrCodeImage(content: String, modifier: Modifier = Modifier) {
    val bitmap = produceState<Bitmap?>(initialValue = null, content) {
        value = null
        value = withContext(Dispatchers.Default) { createQrBitmap(content) }
    }.value

    if (bitmap != null) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = "Temporary Telegram login QR code",
            contentScale = ContentScale.Fit,
            modifier = modifier
                .background(Color.White)
                .padding(8.dp)
        )
    }
}

private fun createQrBitmap(content: String): Bitmap? = runCatching {
    val size = 512
    val matrix = MultiFormatWriter().encode(
        content,
        BarcodeFormat.QR_CODE,
        size,
        size,
        mapOf(EncodeHintType.MARGIN to 4)
    )
    val pixels = IntArray(size * size) { index ->
        if (matrix[index % size, index / size]) AndroidColor.BLACK else AndroidColor.WHITE
    }
    Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888).apply {
        setPixels(pixels, 0, size, 0, 0, size, size)
    }
}.getOrNull()
