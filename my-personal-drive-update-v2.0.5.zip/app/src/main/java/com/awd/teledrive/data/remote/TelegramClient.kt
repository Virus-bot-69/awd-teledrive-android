package com.awd.teledrive.data.remote

import android.util.Log
import com.awd.teledrive.data.account.AccountStore
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.filterIsInstance
import org.drinkless.tdlib.Client
import org.drinkless.tdlib.TdApi
import java.util.concurrent.atomic.AtomicReference
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Owns the TDLib client for each account database directory.
 * tdlibx's Client wrapper has no close() method, so clients are retained and reused when
 * switching accounts. Updates are accepted only from the currently active client.
 */
@Singleton
class TelegramClient @Inject constructor(
    private val accountStore: AccountStore
) {
    companion object {
        private const val TAG = "TelegramClient"
        private const val LEGACY_DIR = "tdlib"
    }

    private val clients = HashMap<String, Client>()

    @Volatile
    private var current: Client? = null

    /** Folder name (inside filesDir) the active client is using. */
    @Volatile
    var databaseDirectoryName: String = runCatching { accountStore.activeTelegramDbDir() }
        .getOrDefault(LEGACY_DIR)
        private set

    private val _updates = MutableSharedFlow<TdApi.Object>(extraBufferCapacity = 500)
    val updates = _updates.asSharedFlow()

    val fileUpdates = updates.filterIsInstance<TdApi.UpdateFile>()

    init {
        activate(databaseDirectoryName)
    }

    @Synchronized
    private fun activate(dirName: String) {
        databaseDirectoryName = dirName
        clients[dirName]?.let { existing ->
            Log.d(TAG, "activate(): reusing client for $dirName")
            current = existing
            requestAuthorizationState(existing)
            return
        }

        current = null
        try {
            System.loadLibrary("tdjni")
            Log.d(TAG, "activate(): creating client for $dirName")
            val clientRef = AtomicReference<Client?>()
            val client = Client.create(
                { update ->
                    if (current === clientRef.get()) _updates.tryEmit(update)
                },
                null,
                null,
            )
            clientRef.set(client)
            clients[dirName] = client
            current = client
            requestAuthorizationState(client)
        } catch (e: UnsatisfiedLinkError) {
            Log.e(TAG, "Failed to load TDLib native library", e)
        } catch (e: Exception) {
            Log.e(TAG, "Error creating TDLib client", e)
        }
    }

    private fun requestAuthorizationState(client: Client) {
        client.send(TdApi.GetAuthorizationState()) { result ->
            if (current === client && result is TdApi.AuthorizationState) {
                _updates.tryEmit(TdApi.UpdateAuthorizationState(result))
            }
        }
    }

    /** Switches the active TDLib client to [dirName] (default: the active account's folder). */
    fun restart(dirName: String = accountStore.activeTelegramDbDir()) {
        Log.d(TAG, "restart() -> $dirName")
        activate(dirName)
    }

    /** Closes and recreates only the active TDLib client without calling Client.close(). */
    @Synchronized
    fun resetActiveClient() {
        val dirName = databaseDirectoryName
        val previous = clients.remove(dirName)
        if (previous == null) {
            activate(dirName)
            return
        }
        if (current === previous) current = null
        previous.send(TdApi.Close()) {
            synchronized(this) {
                if (databaseDirectoryName == dirName && current == null) activate(dirName)
            }
        }
    }

    val isReady: Boolean get() = current != null

    fun send(
        function: TdApi.Function<out TdApi.Object>,
        resultHandler: Client.ResultHandler = Client.ResultHandler { }
    ) {
        val client = current
        if (client != null) {
            client.send(function, resultHandler)
        } else {
            Log.e(TAG, "Cannot send request: client is null (initialization failed?)")
            resultHandler.onResult(TdApi.Error(500, "TDLib client not initialized"))
        }
    }
}
