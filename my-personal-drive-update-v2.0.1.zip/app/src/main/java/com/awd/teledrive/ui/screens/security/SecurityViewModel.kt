package com.awd.teledrive.ui.screens.security

import androidx.lifecycle.ViewModel
import com.awd.teledrive.data.secure.MasterPasswordService
import com.awd.teledrive.data.secure.SecureSessionManager
import com.awd.teledrive.data.secure.SecureSettings
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

@HiltViewModel
class SecurityViewModel @Inject constructor(
    private val masterPasswordService: MasterPasswordService,
    private val secureSettings: SecureSettings,
    private val secureSessionManager: SecureSessionManager
) : ViewModel() {

    private val _isPasswordSet = MutableStateFlow(masterPasswordService.isPasswordSet())
    val isPasswordSet = _isPasswordSet.asStateFlow()

    private val _isSecurityEnabled = MutableStateFlow(
        secureSettings.isSecurityEnabled() && masterPasswordService.isPasswordSet()
    )
    val isSecurityEnabled = _isSecurityEnabled.asStateFlow()

    private val _isBiometricEnabled = MutableStateFlow(
        secureSettings.getBoolean("biometric_enabled") &&
            secureSettings.isSecurityEnabled() && masterPasswordService.isPasswordSet()
    )
    val isBiometricEnabled = _isBiometricEnabled.asStateFlow()

    private val _isLocked = MutableStateFlow(
        secureSettings.isSecurityEnabled() && masterPasswordService.isPasswordSet()
    )
    val isLocked = _isLocked.asStateFlow()

    init {
        // Clear a stale enabled flag from older builds if no password was ever stored.
        if (secureSettings.isSecurityEnabled() && !masterPasswordService.isPasswordSet()) {
            secureSettings.setSecurityEnabled(false)
        }
    }

    fun setSecurityEnabled(enabled: Boolean) {
        val effective = enabled && _isPasswordSet.value
        secureSettings.setSecurityEnabled(effective)
        _isSecurityEnabled.value = effective
        if (!effective) {
            _isLocked.value = false
            secureSessionManager.clearSession()
            secureSettings.saveBoolean("biometric_enabled", false)
            _isBiometricEnabled.value = false
        }
    }

    fun setLocked(locked: Boolean) {
        if (_isSecurityEnabled.value && _isPasswordSet.value) {
            _isLocked.value = locked
            if (locked) {
                secureSessionManager.clearSession()
            }
        }
    }

    private val _error = MutableStateFlow<String?>(null)
    val error = _error.asStateFlow()

    fun unlockSecureMode(password: String): Boolean {
        return if (masterPasswordService.verifyPassword(password)) {
            secureSessionManager.setSessionPassword(password)
            true
        } else false
    }

    fun lockSecureMode() {
        secureSessionManager.clearSession()
    }

    fun unlockWithBiometric(): Boolean {
        val storedPassword = masterPasswordService.getStoredPassword()
        return if (!storedPassword.isNullOrBlank()) {
            secureSessionManager.setSessionPassword(storedPassword)
            true
        } else false
    }

    fun unlockAppWithBiometric(): Boolean {
        val storedPassword = masterPasswordService.getStoredPassword()
        return if (!storedPassword.isNullOrBlank()) {
            _isLocked.value = false
            true
        } else false
    }

    val isSecureModeActive = secureSessionManager.decryptedPassword.map { it != null }

    fun setPassword(password: String): Boolean {
        if (!masterPasswordService.setPassword(password)) return false
        _isPasswordSet.value = true
        setSecurityEnabled(true)
        _isLocked.value = false
        return true
    }

    fun setBiometricEnabled(enabled: Boolean) {
        val effective = enabled && _isSecurityEnabled.value && _isPasswordSet.value
        secureSettings.saveBoolean("biometric_enabled", effective)
        _isBiometricEnabled.value = effective
    }

    fun verifyPassword(password: String): Boolean {
        val isValid = masterPasswordService.verifyPassword(password)
        if (!isValid) {
            _error.value = "Incorrect password"
        } else {
            _error.value = null
            _isLocked.value = false
        }
        return isValid
    }
}
