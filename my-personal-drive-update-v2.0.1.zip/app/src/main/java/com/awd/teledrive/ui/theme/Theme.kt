package com.awd.teledrive.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage

@Composable
fun TeledriveTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    primaryColor: Color = Color(0xFF24A1DE),
    backgroundImageUri: String? = null,
    content: @Composable () -> Unit
) {
    val hasWallpaper = !backgroundImageUri.isNullOrBlank()
    val backgroundColor = if (hasWallpaper) Color.Transparent else if (darkTheme) Color(0xFF1C1B1F) else Color(0xFFFFFBFE)
    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = primaryColor,
            onPrimary = Color.White,
            primaryContainer = primaryColor.copy(alpha = 0.3f),
            onPrimaryContainer = Color.White,
            secondary = primaryColor.copy(alpha = 0.7f),
            onSecondary = Color.White,
            tertiary = Color(0xFFFFC107),
            onTertiary = Color.Black,
            background = backgroundColor,
            surface = Color(0xFF1C1B1F),
            onSurface = Color(0xFFE6E1E5)
        )
    } else {
        lightColorScheme(
            primary = primaryColor,
            onPrimary = Color.White,
            primaryContainer = primaryColor.copy(alpha = 0.1f),
            onPrimaryContainer = primaryColor,
            secondary = primaryColor.copy(alpha = 0.8f),
            onSecondary = Color.White,
            tertiary = Color(0xFFFFA000),
            onTertiary = Color.White,
            background = backgroundColor,
            surface = Color(0xFFFFFBFE),
            onSurface = Color(0xFF1C1B1F)
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
    ) {
        Box(Modifier.fillMaxSize().background(if (darkTheme) Color(0xFF1C1B1F) else Color(0xFFFFFBFE))) {
            if (hasWallpaper) {
                AsyncImage(
                    model = backgroundImageUri,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                    alpha = 0.68f
                )
                Box(
                    Modifier.fillMaxSize().background(
                        if (darkTheme) Color(0x991C1B1F) else Color(0x99FFFBFE)
                    )
                )
            }
            content()
        }
    }
}
