package com.awd.teledrive.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.lifecycle.ViewModel
import com.awd.teledrive.data.secure.SecureSettings
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject

@HiltViewModel
class ThemeViewModel @Inject constructor(
    private val secureSettings: SecureSettings,
) : ViewModel() {
    private val _isDarkMode = MutableStateFlow(
        if (secureSettings.getString("theme_mode_key") == null) null 
        else secureSettings.getBoolean("theme_mode")
    )
    val isDarkMode = _isDarkMode.asStateFlow()

    private val _themeColor = MutableStateFlow(
        Color(secureSettings.getInt("theme_color", 0xFF24A1DE.toInt()))
    )
    val themeColor = _themeColor.asStateFlow()

    private val _backgroundColor = MutableStateFlow(
        if (secureSettings.getBoolean("theme_background_color_enabled", false)) {
            Color(secureSettings.getInt("theme_background_color", 0xFF1C1B1F.toInt()))
        } else null
    )
    val backgroundColor = _backgroundColor.asStateFlow()

    private val _backgroundImageUri = MutableStateFlow(
        secureSettings.getString("theme_background_image_uri", "")?.takeIf { it.isNotBlank() }
    )
    val backgroundImageUri = _backgroundImageUri.asStateFlow()

    fun setBackgroundColor(color: Color?) {
        _backgroundColor.value = color
        secureSettings.saveBoolean("theme_background_color_enabled", color != null)
        if (color != null) {
            secureSettings.saveInt("theme_background_color", color.toArgb())
        }
    }

    fun setBackgroundImage(uri: String?) {
        _backgroundImageUri.value = uri?.takeIf { it.isNotBlank() }
        secureSettings.saveString("theme_background_image_uri", _backgroundImageUri.value ?: "")
    }

    fun setDarkMode(enabled: Boolean?) {
        _isDarkMode.value = enabled
        if (enabled == null) {
            secureSettings.saveString("theme_mode_key", "system")
        } else {
            secureSettings.saveString("theme_mode_key", "set")
            secureSettings.saveBoolean("theme_mode", enabled)
        }
    }

    fun setThemeColor(color: Color) {
        _themeColor.value = color
        secureSettings.saveInt("theme_color", color.toArgb())
    }
}
