package com.awd.teledrive.data.secure

import android.util.Log
import com.lambdapioneer.argon2kt.Argon2Kt
import com.lambdapioneer.argon2kt.Argon2Mode
import java.security.MessageDigest
import java.security.SecureRandom
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MasterPasswordService @Inject constructor(
    private val secureSettings: SecureSettings
) {
    private var argon2Kt: Argon2Kt? = try {
        Argon2Kt()
    } catch (e: UnsatisfiedLinkError) {
        Log.e("MasterPasswordService", "Argon2Kt native library failed to load", e)
        null
    } catch (e: Exception) {
        Log.e("MasterPasswordService", "Argon2Kt initialization failed", e)
        null
    }
    
    private val saltKey = "master_password_salt"
    private val hashKey = "master_password_hash"
    private val rawKey = "master_password_raw"
    private val recoverySaltKey = "master_password_recovery_salt"
    private val recoveryHashKey = "master_password_recovery_hash"
    private val recoveryUsedKey = "master_password_recovery_used"

    fun isPasswordSet(): Boolean {
        return secureSettings.getString(hashKey) != null
    }

    fun setPassword(password: String): Boolean {
        if (password.isBlank()) return false
        val salt = generateSalt()
        val hash = hashPassword(password, salt) ?: return false
        secureSettings.saveString(saltKey, bytesToHex(salt))
        secureSettings.saveString(hashKey, hash)
        // EncryptedSharedPreferences keeps the biometric unlock credential protected at rest.
        secureSettings.saveString(rawKey, password)
        return true
    }

    fun getStoredPassword(): String? {
        return secureSettings.getString(rawKey)
    }

    fun verifyPassword(password: String): Boolean {
        val saltHex = secureSettings.getString(saltKey) ?: return false
        val storedHash = secureSettings.getString(hashKey) ?: return false
        return runCatching {
            val salt = hexToBytes(saltHex)
            hashPassword(password, salt) == storedHash
        }.getOrDefault(false)
    }

    fun changePassword(currentPassword: String, newPassword: String): Boolean {
        if (newPassword.isBlank() || !verifyPassword(currentPassword)) return false
        return setPassword(newPassword)
    }

    fun hasUnusedRecoveryCode(): Boolean {
        return secureSettings.getString(recoveryHashKey) != null &&
            !secureSettings.getBoolean(recoveryUsedKey, false)
    }

    /** Creates and stores only a salted hash. The clear-text code is returned once to the UI. */
    fun createRecoveryCode(): String? {
        val rawCode = generateRecoveryCode()
        val salt = generateSalt()
        val hash = hashRecoveryCode(rawCode, salt)
        secureSettings.saveString(recoverySaltKey, bytesToHex(salt))
        secureSettings.saveString(recoveryHashKey, hash)
        secureSettings.saveBoolean(recoveryUsedKey, false)
        return rawCode.chunked(4).joinToString("-")
    }

    fun verifyRecoveryCode(code: String): Boolean {
        if (!hasUnusedRecoveryCode()) return false
        val saltHex = secureSettings.getString(recoverySaltKey) ?: return false
        val storedHash = secureSettings.getString(recoveryHashKey) ?: return false
        return runCatching {
            val computed = hashRecoveryCode(code, hexToBytes(saltHex))
            MessageDigest.isEqual(computed.toByteArray(), storedHash.toByteArray())
        }.getOrDefault(false)
    }

    /** Consumes the supplied code and returns a fresh one-time code for the newly reset password. */
    fun resetPasswordWithRecoveryCode(code: String, newPassword: String): String? {
        if (newPassword.isBlank() || !verifyRecoveryCode(code)) return null
        if (!setPassword(newPassword)) return null
        secureSettings.saveBoolean(recoveryUsedKey, true)
        return createRecoveryCode()
    }

    private fun normalizeRecoveryCode(code: String): String =
        code.filter { it.isLetterOrDigit() }.uppercase()

    // The recovery code has 80 bits of randomness, so a salted SHA-256 hash avoids the
    // extra Argon2 cost while remaining infeasible to brute-force offline.
    private fun hashRecoveryCode(code: String, salt: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(salt)
        digest.update(normalizeRecoveryCode(code).toByteArray(Charsets.UTF_8))
        return bytesToHex(digest.digest())
    }

    private fun generateRecoveryCode(): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val random = SecureRandom()
        return buildString(16) {
            repeat(16) { append(alphabet[random.nextInt(alphabet.length)]) }
        }
    }

    private fun hashPassword(password: String, salt: ByteArray): String? {
        val argon = argon2Kt ?: return null
        return try {
            val result = argon.hash(
                mode = Argon2Mode.ARGON2_ID,
                password = password.toByteArray(),
                salt = salt,
                tCostInIterations = 2,
                mCostInKibibyte = 65536,
                parallelism = 1
            )
            result.encodedOutputAsString()
        } catch (e: Exception) {
            Log.e("MasterPasswordService", "Hashing failed", e)
            null
        }
    }

    private fun generateSalt(): ByteArray {
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        return salt
    }

    private fun bytesToHex(bytes: ByteArray): String {
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun hexToBytes(hex: String): ByteArray {
        if (hex.isEmpty()) return ByteArray(0)
        val bytes = ByteArray(hex.length / 2)
        for (i in 0 until hex.length step 2) {
            bytes[i / 2] = hex.substring(i, i + 2).toInt(16).toByte()
        }
        return bytes
    }
}
