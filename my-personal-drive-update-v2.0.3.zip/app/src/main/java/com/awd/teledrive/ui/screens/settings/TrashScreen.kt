package com.awd.teledrive.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.RestoreFromTrash
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import com.awd.teledrive.domain.model.DriveItem
import com.awd.teledrive.domain.model.TrashEntry
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrashScreen(
    onBack: () -> Unit,
    viewModel: TrashViewModel = hiltViewModel()
) {
    val entries by viewModel.entries.collectAsState()
    var selectedForPermanentDelete by remember { mutableStateOf<TrashEntry?>(null) }

    LaunchedEffect(Unit) { viewModel.refresh() }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Trash") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding),
            verticalArrangement = Arrangement.Top
        ) {
            Text(
                "Items here can be restored. Their Telegram copies remain in the original chats (usually Saved Messages) until you permanently delete them or their retention period expires.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)
            )
            HorizontalDivider()
            if (entries.isEmpty()) {
                Text(
                    "Trash is empty.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(32.dp)
                )
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(entries, key = { it.key }) { entry ->
                        val isSecure = when (val item = entry.item) {
                            is DriveItem.File -> item.isEncrypted
                            is DriveItem.Folder -> item.isSecure
                        }
                        val title = if (isSecure) {
                            if (entry.item is DriveItem.Folder) "Secure folder" else "Secure file"
                        } else entry.item.name
                        val type = when (entry.item) {
                            is DriveItem.File -> "File · ${formatFileSize(entry.item.size)}"
                            is DriveItem.Folder -> "Folder"
                        }
                        val deletedDate = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
                            .format(Date(entry.deletedAt * 1000L))

                        ListItem(
                            leadingContent = {
                                Icon(
                                    imageVector = if (entry.item is DriveItem.Folder) Icons.Default.Folder else Icons.Default.InsertDriveFile,
                                    contentDescription = null
                                )
                            },
                            headlineContent = {
                                Text(title, maxLines = 1, fontFamily = if (entry.item is DriveItem.File && entry.item.name == "Deleted item") FontFamily.Monospace else FontFamily.Default)
                            },
                            supportingContent = { Text("$type · Deleted $deletedDate") },
                            trailingContent = {
                                Column(horizontalAlignment = Alignment.End) {
                                    TextButton(onClick = { viewModel.restore(entry) }) {
                                        Icon(Icons.Default.RestoreFromTrash, contentDescription = null)
                                        Text("Restore", modifier = Modifier.padding(start = 4.dp))
                                    }
                                    TextButton(onClick = { selectedForPermanentDelete = entry }) {
                                        Icon(Icons.Default.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                        Text("Delete permanently", color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(start = 4.dp))
                                    }
                                }
                            }
                        )
                        HorizontalDivider()
                    }
                }
            }
        }
    }

    selectedForPermanentDelete?.let { entry ->
        AlertDialog(
            onDismissRequest = { selectedForPermanentDelete = null },
            title = { Text("Delete permanently?") },
            text = { Text("This immediately removes the Telegram copy from its original chat (including Saved Messages). This action cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deletePermanently(entry)
                    selectedForPermanentDelete = null
                }) {
                    Text("Delete permanently", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedForPermanentDelete = null }) { Text("Cancel") }
            }
        )
    }
}

private fun formatFileSize(size: Long): String {
    if (size < 1024) return "$size B"
    val units = listOf("KB", "MB", "GB", "TB")
    var value = size.toDouble()
    var unitIndex = -1
    do {
        value /= 1024.0
        unitIndex++
    } while (value >= 1024.0 && unitIndex < units.lastIndex)
    return String.format(Locale.getDefault(), "%.1f %s", value, units[unitIndex])
}
