package com.awd.teledrive.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage

@Composable
fun TeledriveTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    primaryColor: Color = Color(0xFF24A1DE),
    backgroundImageUri: String? = null,
    backgroundColorOverride: Color? = null,
    content: @Composable () -> Unit
) {
    val hasWallpaper = !backgroundImageUri.isNullOrBlank()
    val defaultBackground = if (darkTheme) Color(0xFF1C1B1F) else Color(0xFFFFFBFE)
    val appBackground = backgroundColorOverride ?: defaultBackground
    val schemeBackground = if (hasWallpaper) Color.Transparent else appBackground
    val surfaceColor = if (hasWallpaper) appBackground.copy(alpha = 0.78f) else appBackground
    val foreground = if (appBackground.luminance() > 0.55f) Color(0xFF1C1B1F) else Color(0xFFF7F2FA)

    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = primaryColor,
            onPrimary = Color.White,
            primaryContainer = primaryColor.copy(alpha = 0.3f),
            onPrimaryContainer = foreground,
            secondary = primaryColor.copy(alpha = 0.7f),
            onSecondary = Color.White,
            tertiary = Color(0xFFFFC107),
            onTertiary = Color.Black,
            background = schemeBackground,
            surface = surfaceColor,
            surfaceVariant = surfaceColor.copy(alpha = 0.92f),
            onSurface = foreground,
            onSurfaceVariant = foreground.copy(alpha = 0.78f)
        )
    } else {
        lightColorScheme(
            primary = primaryColor,
            onPrimary = Color.White,
            primaryContainer = primaryColor.copy(alpha = 0.1f),
            onPrimaryContainer = foreground,
            secondary = primaryColor.copy(alpha = 0.8f),
            onSecondary = Color.White,
            tertiary = Color(0xFFFFA000),
            onTertiary = Color.White,
            background = schemeBackground,
            surface = surfaceColor,
            surfaceVariant = surfaceColor.copy(alpha = 0.92f),
            onSurface = foreground,
            onSurfaceVariant = foreground.copy(alpha = 0.78f)
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
    ) {
        Box(Modifier.fillMaxSize().background(appBackground)) {
            if (hasWallpaper) {
                AsyncImage(
                    model = backgroundImageUri,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                    alpha = 0.68f
                )
                Box(
                    Modifier.fillMaxSize().background(appBackground.copy(alpha = 0.62f))
                )
            }
            content()
        }
    }
}
