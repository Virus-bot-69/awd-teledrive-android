package com.awd.teledrive.ui.screens.security

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun RecoveryCodeDialog(
    code: String,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Save your one-time recovery code") },
        text = {
            Column {
                Text("This code is shown only once. Write it down or store it somewhere private. Anyone who has it can reset your Master Password. Do not share it.")
                Spacer(Modifier.height(12.dp))
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        code,
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(16.dp)
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "The code can be used once. After recovery, a new code will be generated.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("I've saved it") }
        }
    )
}

@Composable
fun ChangeMasterPasswordDialog(
    onDismiss: () -> Unit,
    onChangePassword: (currentPassword: String, newPassword: String) -> Boolean
) {
    var currentPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Change Master Password") },
        text = {
            Column {
                Text("Enter your current password, then choose and confirm a new one. The stored password is never displayed.")
                Spacer(Modifier.height(10.dp))
                PasswordField(
                    value = currentPassword,
                    onValueChange = { currentPassword = it; error = null },
                    label = "Current password",
                    visible = passwordVisible,
                    onToggleVisibility = { passwordVisible = !passwordVisible }
                )
                PasswordField(
                    value = newPassword,
                    onValueChange = { newPassword = it; error = null },
                    label = "New password",
                    visible = passwordVisible,
                    onToggleVisibility = { passwordVisible = !passwordVisible }
                )
                PasswordField(
                    value = confirmPassword,
                    onValueChange = { confirmPassword = it; error = null },
                    label = "Confirm new password",
                    visible = passwordVisible,
                    onToggleVisibility = { passwordVisible = !passwordVisible }
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    currentPassword.isBlank() -> error = "Enter your current password."
                    newPassword.length < 4 -> error = "Use at least 4 characters for the new password."
                    newPassword != confirmPassword -> error = "The new passwords do not match."
                    !onChangePassword(currentPassword, newPassword) -> error = "Current password is incorrect or the change could not be saved."
                    else -> onDismiss()
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun SetRecoveryCodeDialog(
    onDismiss: () -> Unit,
    onCreateRecoveryCode: (currentPassword: String) -> String?,
    onCodeCreated: (String) -> Unit
) {
    var currentPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create or reset recovery code") },
        text = {
            Column {
                Text("Verify your current Master Password. The new one-time code replaces any previous recovery code.")
                Spacer(Modifier.height(10.dp))
                PasswordField(
                    value = currentPassword,
                    onValueChange = { currentPassword = it; error = null },
                    label = "Current Master Password",
                    visible = passwordVisible,
                    onToggleVisibility = { passwordVisible = !passwordVisible }
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (currentPassword.isBlank()) {
                    error = "Enter your current password."
                } else {
                    val code = onCreateRecoveryCode(currentPassword)
                    if (code == null) error = "Current password is incorrect or the code could not be generated."
                    else {
                        onDismiss()
                        onCodeCreated(code)
                    }
                }
            }) { Text("Generate code") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun RecoveryPasswordResetDialog(
    recoveryCodeAvailable: Boolean = true,
    onDismiss: () -> Unit,
    onRecover: (recoveryCode: String, newPassword: String) -> String?,
    onRecoveryComplete: (newRecoveryCode: String) -> Unit
) {
    var recoveryCode by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Recover Master Password") },
        text = {
            Column {
                Text("Enter the one-time recovery code you saved and choose a new password. Telegram login codes cannot be used here.")
                if (!recoveryCodeAvailable) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "No recovery code is currently set up. If you still know your password, unlock the app and create a code in Settings first.",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = recoveryCode,
                    onValueChange = { recoveryCode = it; error = null },
                    label = { Text("Recovery code") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                PasswordField(
                    value = newPassword,
                    onValueChange = { newPassword = it; error = null },
                    label = "New password",
                    visible = passwordVisible,
                    onToggleVisibility = { passwordVisible = !passwordVisible }
                )
                PasswordField(
                    value = confirmPassword,
                    onValueChange = { confirmPassword = it; error = null },
                    label = "Confirm new password",
                    visible = passwordVisible,
                    onToggleVisibility = { passwordVisible = !passwordVisible }
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    recoveryCode.isBlank() -> error = "Enter your recovery code."
                    newPassword.length < 4 -> error = "Use at least 4 characters for the new password."
                    newPassword != confirmPassword -> error = "The new passwords do not match."
                    else -> {
                        val newRecoveryCode = onRecover(recoveryCode, newPassword)
                        if (newRecoveryCode == null) {
                            error = "The recovery code is invalid, already used, or has not been set up."
                        } else {
                            onDismiss()
                            onRecoveryComplete(newRecoveryCode)
                        }
                    }
                }
            }) { Text("Reset password") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun PasswordField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    visible: Boolean,
    onToggleVisibility: () -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        trailingIcon = {
            IconButton(onClick = onToggleVisibility) {
                Icon(
                    imageVector = if (visible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                    contentDescription = if (visible) "Hide password" else "Show password"
                )
            }
        },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}
