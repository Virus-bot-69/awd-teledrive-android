package com.awd.teledrive.data.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.awd.teledrive.data.repository.DriveRepository
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

class TrashCleanupWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    @EntryPoint
    @InstallIn(SingletonComponent::class)
    interface TrashWorkerEntryPoint {
        fun driveRepository(): DriveRepository
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val entryPoint = EntryPointAccessors.fromApplication(
                applicationContext,
                TrashWorkerEntryPoint::class.java
            )
            val driveRepository = entryPoint.driveRepository()
            suspendCancellableCoroutine { continuation ->
                val resumed = AtomicBoolean(false)
                driveRepository.purgeExpiredTrash { success ->
                    if (resumed.compareAndSet(false, true) && continuation.isActive) {
                        continuation.resume(if (success) Result.success() else Result.retry())
                    }
                }
            }
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
