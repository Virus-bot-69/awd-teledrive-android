package com.awd.teledrive.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.awd.teledrive.data.repository.DriveRepository
import com.awd.teledrive.domain.model.TrashEntry
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class TrashViewModel @Inject constructor(
    private val driveRepository: DriveRepository
) : ViewModel() {

    val entries: StateFlow<List<TrashEntry>> = driveRepository.getTrashEntries()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun refresh() {
        driveRepository.fetchFiles()
    }

    fun restore(entry: TrashEntry) {
        driveRepository.restoreTrashEntry(entry.key)
    }

    fun deletePermanently(entry: TrashEntry) {
        driveRepository.permanentlyDeleteTrashEntry(entry)
    }
}
